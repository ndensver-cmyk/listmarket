# MercadoList

Tu mercado organizado. Tus precios bajo control. Android · Kotlin + Jetpack Compose · Colombia · COP.

## Compilar en GitHub
1. Sube esta carpeta a un repositorio (rama `main`).
2. Ve a **Actions → Build MercadoList**; se ejecuta solo con cada push (o con *Run workflow*).
3. Al terminar, descarga el APK desde **Artifacts → MercadoList-debug-apk**.

El workflow (`.github/workflows/build.yml`) instala JDK 17, el SDK de Android y Gradle 8.10.2,
ejecuta las pruebas (verifica ≥ 5.000 referencias en el catálogo) y compila el APK de depuración.
No necesita `gradlew`; si quieres el wrapper local, abre el proyecto en Android Studio.

## Qué incluye
- Catálogo local de 5.500+ referencias (marcas colombianas, marcas propias separadas, presentaciones y variantes) — `app/src/main/assets/catalog_seed.txt`.
- Listas (crear, duplicar, plantillas, compartir, PDF, presupuesto por lista, presentaciones, manuales), carrito y finalizar compra.
- Comparador: un producto, lista completa por tienda y distribución con transporte/domicilio; precios >30 días nunca cuentan como vigentes.
- Presupuesto semanal/quincenal/mensual (general y por categoría), alertas, comparación con el periodo anterior y gráficos.
- Escáner EAN (ML Kit), favoritos, sustitutos, precio por kg/L/un, historial de precios, inventario doméstico, recordatorios, tema oscuro.
- Importar CSV de precios, códigos de barras y fotos.

## Datos reales (importante)
El catálogo es una base de referencias **sin precios, sin EAN y sin fotos**: no se inventan.
Se llenan con el registro manual, el escáner o el CSV (`sku;tienda;ciudad;precio[;precio_antes]`,
`sku;EAN`, `sku;urlFoto`). La combinación marca × presentación × variante debe verificarse contra el producto real.

## Novedades (versión 1.1)
- **Fotos:** cada producto muestra una imagen con ícono por tipo; en Perfil → "Buscar fotos" se descargan fotos reales de Open Food Facts cuando coinciden marca y producto.
- **Precios por supermercado:** al abrir la app por primera vez se cargan precios *estimados* (promedios de referencia) distintos por tienda (D1 y Ara más bajos, Carulla y Jumbo más altos; marcas propias solo en su tienda). Siempre se marcan como "estimado" y los precios reales los reemplazan.
- **Precios reales:** `assets/real_prices.txt` (hoy: café Juan Valdez y chocolate Corona de la app de Éxito). Agrega más líneas con el mismo formato.
- **Animación de inicio:** carrito que rebota con productos que caen dentro.
