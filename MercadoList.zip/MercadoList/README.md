# MercadoList

Tu mercado organizado. Tus precios bajo control. Android · Kotlin + Jetpack Compose · Colombia · COP.

## Compilar en GitHub
1. Sube esta carpeta a un repositorio (rama `main`).
2. Ve a **Actions → Build MercadoList**; se ejecuta solo con cada push (o con *Run workflow*).
3. Al terminar, descarga el APK desde **Artifacts → MercadoList-debug-apk**.

El workflow (`.github/workflows/build.yml`) instala JDK 17, el SDK de Android y Gradle 8.10.2,
ejecuta las pruebas (verifica ≥ 5.000 referencias en el catálogo) y compila el APK de depuración.
No necesita `gradlew`; si quieres el wrapper local, abre el proyecto en Android Studio.

## Qué incluye
- Catálogo local de 5.500+ referencias (marcas colombianas, marcas propias separadas, presentaciones y variantes) — `app/src/main/assets/catalog_seed.txt`.
- Listas (crear, duplicar, plantillas, compartir, PDF, presupuesto por lista, presentaciones, manuales), carrito y finalizar compra.
- Comparador: un producto, lista completa por tienda y distribución con transporte/domicilio; precios >30 días nunca cuentan como vigentes.
- Presupuesto semanal/quincenal/mensual (general y por categoría), alertas, comparación con el periodo anterior y gráficos.
- Escáner EAN (ML Kit), favoritos, sustitutos, precio por kg/L/un, historial de precios, inventario doméstico, recordatorios, tema oscuro.
- Importar CSV de precios, códigos de barras y fotos.

## Datos reales (importante)
El catálogo es una base de referencias **sin precios, sin EAN y sin fotos**: no se inventan.
Se llenan con el registro manual, el escáner o el CSV (`sku;tienda;ciudad;precio[;precio_antes]`,
`sku;EAN`, `sku;urlFoto`). La combinación marca × presentación × variante debe verificarse contra el producto real.
