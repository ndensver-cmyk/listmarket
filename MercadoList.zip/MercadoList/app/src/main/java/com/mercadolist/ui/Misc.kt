@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.mercadolist.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mercadolist.core.*
import com.mercadolist.data.*
import com.mercadolist.goTab
import kotlinx.coroutines.launch

// ============================ HISTORIAL ============================

@Composable
fun HistoryScreen(vm: AppVM, nav: NavController) {
    val purchases by vm.purchases.collectAsState()
    var open by remember { mutableStateOf<Long?>(null) }
    var detail by remember { mutableStateOf<List<PurchaseItemEntity>>(emptyList()) }
    val scope = rememberCoroutineScope()

    Screen(title = "Historial de mercados", onBack = { nav.popBackStack() }) { pad ->
        if (purchases.isEmpty()) EmptyState(Icons.Filled.History, "Sin compras todavía", "Cuando finalices un mercado desde el carrito, quedará guardado aquí y podrás repetirlo.", Modifier.padding(pad))
        else LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(purchases, key = { it.id }) { p ->
                InfoCard {
                    Row(Modifier.clickable {
                        if (open == p.id) open = null else { open = p.id; scope.launch { detail = vm.purchaseItems(p.id) } }
                    }, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text("${Fmt.date(p.date)}${if (p.storeName.isNotBlank()) " · ${p.storeName}" else ""}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(Fmt.cop(p.total), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }
                    if (open == p.id) {
                        Spacer(Modifier.height(6.dp))
                        detail.forEach { Row { Text("${Fmt.qty(it.quantity)} × ${it.name}", Modifier.weight(1f), fontSize = 13.sp); Text(Fmt.cop(it.unitPrice * it.quantity), fontSize = 13.sp) } }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.repeatPurchase(p.id, p.name) { id -> nav.navigate("list/$id") } }, colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Ink)) { Text("Repetir mercado") }
                            TextButton(onClick = { vm.deletePurchase(p.id); open = null }) { Text("Eliminar") }
                        }
                    }
                }
            }
        }
    }
}

// ============================ INVENTARIO ============================

@Composable
fun InventoryScreen(vm: AppVM, nav: NavController) {
    val inv by vm.inventory.collectAsState()
    var picker by remember { mutableStateOf(false) }
    var manual by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    Screen(
        title = "Mi despensa", onBack = { nav.popBackStack() },
        fab = {
            Box {
                ExtendedFloatingActionButton(onClick = { menu = true }, containerColor = Yellow, contentColor = Ink) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Agregar") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Del catálogo") }, onClick = { picker = true; menu = false })
                    DropdownMenuItem(text = { Text("Escribir uno") }, onClick = { manual = true; menu = false })
                }
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                InfoCard {
                    Text("Lo que ya tienes en casa", fontWeight = FontWeight.Bold)
                    Text("Registra cantidades y MercadoList te avisará en tus listas qué todavía tienes y qué se acabó, para evitar compras innecesarias y desperdicio.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (inv.any { it.quantity <= 0 }) {
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = { vm.listFromInventory { id -> nav.navigate("list/$id") } }, colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Yellow)) { Text("Crear lista con lo que falta") }
                    }
                }
            }
            if (inv.isEmpty()) item { EmptyState(Icons.Filled.Inventory2, "Despensa vacía", "Ejemplo: Arroz 2 kg, Aceite 1 botella, Leche 0 unidades.") }
            items(inv, key = { it.id }) { i ->
                InfoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(i.name, fontWeight = FontWeight.SemiBold)
                            Text(if (i.quantity <= 0) "Se acabó: inclúyelo en tu próxima lista" else "Tienes suficiente por ahora", fontSize = 12.sp, color = if (i.quantity <= 0) WarnOrange else OkGreen)
                        }
                        QtyStepperZero(i.quantity) { vm.saveInventory(i.copy(quantity = it)) }
                        Text(i.unit, fontSize = 12.sp)
                        IconButton(onClick = { vm.deleteInventory(i) }) { Icon(Icons.Filled.Delete, "Quitar") }
                    }
                }
            }
        }
    }

    if (picker) ProductPickerDialog(vm, onDismiss = { picker = false }) { v ->
        val unit = when (v.unit) { "g" -> "kg"; "ml" -> "L"; else -> "un" }
        vm.saveInventory(InventoryEntity(productId = v.productId, name = v.productName + " " + v.brand, quantity = 1.0, unit = unit))
    }
    if (manual) ManualInventoryDialog(onDismiss = { manual = false }) { n, q, u -> vm.saveInventory(InventoryEntity(name = n, quantity = q, unit = u)) }
}

@Composable
private fun QtyStepperZero(qty: Double, onChange: (Double) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { if (qty > 0) onChange((qty - 1).coerceAtLeast(0.0)) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.Remove, "Menos") }
        Text(Fmt.qty(qty), fontWeight = FontWeight.Bold, modifier = Modifier.widthIn(min = 24.dp))
        IconButton(onClick = { onChange(qty + 1) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.Add, "Más") }
    }
}

@Composable
private fun ManualInventoryDialog(onDismiss: () -> Unit, onSave: (String, Double, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("un") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Producto en casa") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                NumberField(qty, { qty = it }, "Cantidad", Modifier.fillMaxWidth(), decimal = true)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("un", "kg", "g", "L", "ml").forEach { u -> FilterChip(selected = unit == u, onClick = { unit = u }, label = { Text(u) }) } }
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onSave(name.trim(), qty.toQty() ?: 1.0, unit); onDismiss() }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ============================ FAVORITOS ============================

@Composable
fun FavoritesScreen(vm: AppVM, nav: NavController) {
    val rows by vm.favoriteRows.collectAsState()
    var addTo by remember { mutableStateOf<Long?>(null) }
    Screen(title = "Favoritos", onBack = { nav.popBackStack() }) { pad ->
        if (rows.isEmpty()) EmptyState(Icons.Filled.Favorite, "Sin favoritos", "Toca el corazón en la ficha de un producto para guardarlo aquí.", Modifier.padding(pad))
        else LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(rows, key = { it.view.variantId }) { r -> VariantRowCard(r, onClick = { nav.navigate("product/${r.view.variantId}") }, onAdd = { addTo = r.view.variantId }) }
        }
    }
    addTo?.let { AddToListDialog(vm, it, onDismiss = { addTo = null }, onAdded = {}) }
}

// ============================ PERFIL / AJUSTES ============================

@Composable
fun ProfileScreen(vm: AppVM, nav: NavController) {
    val st by vm.settings.collectAsState()
    val count by vm.catalogCount.collectAsState()
    var cityDialog by remember { mutableStateOf(false) }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val days = listOf(2 to "Lun", 3 to "Mar", 4 to "Mié", 5 to "Jue", 6 to "Vie", 7 to "Sáb", 1 to "Dom")

    Screen(title = "Perfil") { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard {
                Text("Mi mercado", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Historial, presupuesto y ajustes", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            listOf(
                Triple("Historial de mercados", Icons.Filled.History, "history"),
                Triple("Presupuesto", Icons.Filled.Savings, "budget"),
                Triple("Supermercados y precios", Icons.Filled.Store, "stores"),
                Triple("Mi despensa", Icons.Filled.Inventory2, "inventory"),
                Triple("Favoritos", Icons.Filled.Favorite, "favorites"),
                Triple("Escanear código de barras", Icons.Filled.QrCodeScanner, "scanner")
            ).forEach { (t, icon, route) ->
                Card(onClick = { nav.navigate(route) }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, null); Spacer(Modifier.width(12.dp)); Text(t, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
                    }
                }
            }

            InfoCard {
                Text("Ajustes", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Text("Tema", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Sistema", 1 to "Claro", 2 to "Oscuro").forEach { (v, l) -> FilterChip(selected = st.dark == v, onClick = { vm.setDark(v) }, label = { Text(l) }) }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Ciudad", fontWeight = FontWeight.SemiBold); Text(st.city, fontSize = 13.sp) }
                    TextButton(onClick = { cityDialog = true }) { Text("Cambiar") }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Recordatorio de mercado", fontWeight = FontWeight.SemiBold); Text("Aviso semanal para hacer tu mercado", fontSize = 12.sp) }
                    Switch(checked = st.remindersOn, onCheckedChange = {
                        if (it && Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        vm.setReminder(it, st.reminderDay, st.reminderHour)
                    })
                }
                if (st.remindersOn) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        days.forEach { (d, l) -> FilterChip(selected = st.reminderDay == d, onClick = { vm.setReminder(true, d, st.reminderHour) }, label = { Text(l) }) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Hora: ${st.reminderHour}:00", Modifier.weight(1f))
                        IconButton(onClick = { vm.setReminder(true, st.reminderDay, (st.reminderHour + 23) % 24) }) { Icon(Icons.Filled.Remove, "Antes") }
                        IconButton(onClick = { vm.setReminder(true, st.reminderDay, (st.reminderHour + 1) % 24) }) { Icon(Icons.Filled.Add, "Después") }
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Sincronización opcional", fontWeight = FontWeight.SemiBold)
                        Text("La app funciona 100 % sin conexión. La nube (Supermercados compartidos, respaldo) se conectará con Supabase cuando se configure.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = st.syncOn, onCheckedChange = { vm.setSync(it) })
                }
            }
            Text("MercadoList 1.0 · $count referencias en el catálogo · Precios en COP", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (cityDialog) TextInputDialog("Ciudad", "Ciudad", st.city, onSave = { vm.setCity(it) }, onDismiss = { cityDialog = false })
}
