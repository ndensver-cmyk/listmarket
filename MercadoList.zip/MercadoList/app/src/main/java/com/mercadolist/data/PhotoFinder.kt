package com.mercadolist.data

import com.mercadolist.core.normalize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Busca una foto en Open Food Facts (base abierta). Solo se acepta si coincide la marca y el producto. */
object PhotoFinder {
    suspend fun find(name: String, brand: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val q = URLEncoder.encode("$name $brand", "UTF-8")
            val url = URL("https://world.openfoodfacts.org/cgi/search.pl?search_terms=$q&search_simple=1&action=process&json=1&page_size=8&fields=product_name,brands,image_front_small_url")
            val c = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000; readTimeout = 8000
                setRequestProperty("User-Agent", "MercadoList/1.0 (app personal de listas de mercado)")
            }
            val body = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val arr = JSONObject(body).optJSONArray("products") ?: return@runCatching null
            val b = normalize(brand)
            val word = normalize(name).split(" ").firstOrNull { it.length > 3 } ?: normalize(name)
            for (i in 0 until arr.length()) {
                val p = arr.getJSONObject(i)
                val img = p.optString("image_front_small_url")
                if (img.isNotBlank() && normalize(p.optString("brands")).contains(b) && normalize(p.optString("product_name")).contains(word)) return@runCatching img
            }
            null
        }.getOrNull()
    }
}
