@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.mercadolist.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mercadolist.core.*
import com.mercadolist.data.CategorySpend

@Composable
fun BudgetScreen(vm: AppVM, nav: NavController) {
    val st by vm.settings.collectAsState()
    val cats by vm.categories.collectAsState()
    val period = st.period
    var offset by remember { mutableIntStateOf(0) }
    var demo by remember { mutableStateOf(false) }
    val range = remember(period, offset) { periodRange(period, offset) }
    val budgets by remember(period) { vm.budgets(period) }.collectAsState(emptyList())
    val spentCat by remember(range) { vm.spendByCategory(range) }.collectAsState(emptyList())
    val spent by remember(range) { vm.spent(range) }.collectAsState(0L)
    val prevSpent by remember(period, offset) { vm.spent(periodRange(period, offset - 1)) }.collectAsState(0L)
    val pendingCart by vm.pendingCart.collectAsState()
    var editCat by remember { mutableStateOf<Long?>(null) } // 0 = general

    val general = budgets.firstOrNull { it.categoryId == 0L }?.amount
    val catBudget = budgets.filter { it.categoryId != 0L }.associate { it.categoryId to it.amount }
    val spentByCat = spentCat.associate { it.categoryId to it.total }
    val demoData = remember(cats) { cats.take(5).mapIndexed { i, c -> c.id to listOf(180000.0, 120000.0, 90000.0, 60000.0, 40000.0)[i] } }
    val shownSpent = if (demo) demoData.sumOf { it.second }.toLong() else spent
    val shownByCat: Map<Long, Double> = if (demo) demoData.toMap() else spentByCat
    val used = shownSpent + (if (demo) 0.0 else pendingCart)

    Screen(title = "Presupuesto", onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("SEMANAL", "QUINCENAL", "MENSUAL").forEach { p ->
                        FilterChip(selected = period == p, onClick = { vm.setPeriod(p); offset = 0 }, label = { Text(periodName(p)) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { offset-- }) { Icon(Icons.Filled.ChevronLeft, "Periodo anterior") }
                    Text(periodLabel(range), Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    IconButton(onClick = { if (offset < 0) offset++ }, enabled = offset < 0) { Icon(Icons.Filled.ChevronRight, "Periodo siguiente") }
                }
            }
            item {
                InfoCard {
                    if (demo) Text("DATOS DE DEMOSTRACIÓN — no son tus gastos", color = WarnOrange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row {
                        Column(Modifier.weight(1f)) { Text("Gastado", fontSize = 12.sp); Text(Fmt.cop(shownSpent), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp) }
                        Column(Modifier.weight(1f)) { Text("Pendiente en carrito", fontSize = 12.sp); Text(Fmt.cop(if (demo) 0.0 else pendingCart), fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                    }
                    Spacer(Modifier.height(8.dp))
                    val base = if (demo) 500000L else general
                    if (base == null) Text("Sin presupuesto general para este periodo.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else {
                        val frac = (used / base).toFloat()
                        LinearProgressIndicator(progress = { frac.coerceIn(0f, 1f) }, Modifier.fillMaxWidth().height(10.dp), color = if (frac > 1f) AlertRed else if (frac >= 0.8f) WarnOrange else Ink)
                        Spacer(Modifier.height(6.dp))
                        Row {
                            Text("Presupuesto ${Fmt.cop(base)}", Modifier.weight(1f), fontSize = 13.sp)
                            Text("Disponible ${Fmt.cop(base - used)}", fontWeight = FontWeight.Bold, color = if (base - used < 0) AlertRed else OkGreen)
                        }
                        if (frac > 1f) Text("⚠ Superaste el presupuesto por ${Fmt.cop(used - base)}.", color = AlertRed, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        else if (frac >= 0.8f) Text("Ya usaste el ${(frac * 100).toInt()} % de tu presupuesto.", color = WarnOrange, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                    TextButton(onClick = { editCat = 0L }) { Text("Editar presupuesto general") }
                }
            }
            item {
                InfoCard {
                    Text("Comparación con el periodo anterior", fontWeight = FontWeight.Bold)
                    if (prevSpent == 0L) Text("No hay compras registradas en el periodo anterior.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else {
                        val diff = shownSpent - prevSpent
                        Text("Antes: ${Fmt.cop(prevSpent)}  ·  Ahora: ${Fmt.cop(shownSpent)}", fontSize = 13.sp)
                        Text(if (diff > 0) "Gastas ${Fmt.cop(diff)} más (${(diff * 100 / prevSpent)} %)" else "Gastas ${Fmt.cop(-diff)} menos (${(-diff * 100 / prevSpent)} %)", color = if (diff > 0) AlertRed else OkGreen, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            item {
                InfoCard {
                    Text("Distribución de gastos", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    val rows = shownByCat.entries.filter { it.value > 0 }.sortedByDescending { it.value }.map { (id, v) -> (cats.firstOrNull { it.id == id }?.name ?: "Sin categoría") to v }
                    if (rows.isEmpty()) Text("Aún no hay compras en este periodo. Cuando finalices un mercado desde el carrito, verás aquí cómo se reparte.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else SpendBars(rows)
                    TextButton(onClick = { demo = !demo }) { Text(if (demo) "Ocultar demostración" else "Ver datos de demostración") }
                }
            }
            item { Text("Presupuesto por categoría", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            items(cats, key = { it.id }) { c ->
                val b = catBudget[c.id]
                val s = shownByCat[c.id] ?: 0.0
                InfoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(catIcon(c.name), null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(c.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        TextButton(onClick = { editCat = c.id }) { Text(b?.let { Fmt.cop(it) } ?: "Definir") }
                    }
                    if (b != null) {
                        val frac = (s / b).toFloat()
                        LinearProgressIndicator(progress = { frac.coerceIn(0f, 1f) }, Modifier.fillMaxWidth().height(6.dp), color = if (frac > 1f) AlertRed else if (frac >= 0.8f) WarnOrange else Ink)
                        Text("Gastado ${Fmt.cop(s)} · ${if (b - s >= 0) "disponible ${Fmt.cop(b - s)}" else "excedido por ${Fmt.cop(s - b)}"}", fontSize = 12.sp, color = if (frac > 1f) AlertRed else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    editCat?.let { id ->
        val initial = if (id == 0L) general else catBudget[id]
        EditAmountDialog(if (id == 0L) "Presupuesto general (${periodName(period).lowercase()})" else "Presupuesto de ${cats.firstOrNull { it.id == id }?.name ?: ""}", initial, onSave = { vm.setBudget(period, id, it) }, onDismiss = { editCat = null })
    }
}
