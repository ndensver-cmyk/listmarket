package com.mercadolist.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("mercadolist_settings")

data class AppSettings(
    val dark: Int = 0, // 0 sistema, 1 claro, 2 oscuro
    val city: String = "Colombia",
    val period: String = "MENSUAL",
    val remindersOn: Boolean = false,
    val reminderDay: Int = 1, // Calendar.DAY_OF_WEEK
    val reminderHour: Int = 9,
    val syncOn: Boolean = false,
    val showEstimates: Boolean = true
)

class SettingsStore(private val context: Context) {
    private val DARK = intPreferencesKey("dark")
    private val CITY = stringPreferencesKey("city")
    private val PERIOD = stringPreferencesKey("period")
    private val REM_ON = booleanPreferencesKey("rem_on")
    private val REM_DAY = intPreferencesKey("rem_day")
    private val REM_HOUR = intPreferencesKey("rem_hour")
    private val SYNC = booleanPreferencesKey("sync")
    private val SHOW_EST = booleanPreferencesKey("show_est")
    private val PRICES_SEEDED = booleanPreferencesKey("prices_seeded_v1")

    val flow: Flow<AppSettings> = context.ds.data.map { p ->
        AppSettings(
            dark = p[DARK] ?: 0, city = p[CITY] ?: "Colombia", period = p[PERIOD] ?: "MENSUAL",
            remindersOn = p[REM_ON] ?: false, reminderDay = p[REM_DAY] ?: 1, reminderHour = p[REM_HOUR] ?: 9,
            syncOn = p[SYNC] ?: false, showEstimates = p[SHOW_EST] ?: true
        )
    }

    suspend fun setDark(v: Int) { context.ds.edit { it[DARK] = v } }
    suspend fun setCity(v: String) { context.ds.edit { it[CITY] = v } }
    suspend fun setPeriod(v: String) { context.ds.edit { it[PERIOD] = v } }
    suspend fun setReminder(on: Boolean, day: Int, hour: Int) {
        context.ds.edit { it[REM_ON] = on; it[REM_DAY] = day; it[REM_HOUR] = hour }
    }
    suspend fun setSync(v: Boolean) { context.ds.edit { it[SYNC] = v } }
    suspend fun setShowEstimates(v: Boolean) { context.ds.edit { it[SHOW_EST] = v } }
    suspend fun pricesSeeded(): Boolean = context.ds.data.first()[PRICES_SEEDED] ?: false
    suspend fun setPricesSeeded() { context.ds.edit { it[PRICES_SEEDED] = true } }
}
