package com.mercadolist.data

/** Una referencia comercial: producto + marca + variante + presentación + contenido. */
data class SeedRef(
    val category: String,
    val subcategory: String,
    val product: String,
    val brand: String,
    val isStoreBrand: Boolean,
    val variant: String,
    val presentation: String,
    val amount: Double,
    val unit: String
)

object CatalogGenerator {
    val categories = listOf(
        "Frutas y verduras", "Carnes, pollo y pescados", "Lácteos y huevos", "Bebidas",
        "Despensa y granos", "Panadería y repostería", "Snacks y dulces", "Limpieza del hogar",
        "Aseo personal", "Mascotas", "Hogar y papelería", "Congelados", "Condimentos y salsas",
        "Bebés y maternidad"
    )
    val codes = listOf("FV", "CP", "LH", "BE", "DG", "PR", "SD", "LM", "AP", "MA", "HP", "CG", "CS", "BM")
    val storeNames = listOf("D1", "Ara", "Éxito", "Olímpica", "Jumbo", "Carulla")

    private val sizeRx = Regex("^([0-9]+(?:\\.[0-9]+)?)(kg|g|ml|l|un)(?::(.+))?$")

    fun generate(lines: List<String>): List<SeedRef> {
        val out = ArrayList<SeedRef>()
        val seen = HashSet<String>()
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val p = line.split("|")
            require(p.size == 6) { "Línea inválida: $line" }
            require(p[0] in categories) { "Categoría desconocida: ${p[0]}" }
            val brands = expandBrands(p[3])
            val sizes = p[4].split(";").map { it.trim() }.filter { it.isNotEmpty() }.map { parseSize(it) }
            val variants = p[5].split(";").map { it.trim() }.filter { it.isNotEmpty() && it != "-" }.ifEmpty { listOf("") }
            for ((brand, isStore) in brands) for ((amount, unit, pres) in sizes) for (v in variants) {
                val key = listOf(p[0], p[1], p[2], brand, v, pres, amount, unit).joinToString("|")
                if (seen.add(key)) out += SeedRef(p[0], p[1], p[2], brand, isStore, v, pres, amount, unit)
            }
        }
        return out
    }

    private fun expandBrands(s: String): List<Pair<String, Boolean>> =
        s.split(";").map { it.trim() }.filter { it.isNotEmpty() }.flatMap {
            when (it) {
                "MP" -> storeNames.map { n -> "Marca propia $n" to true }
                "MP3" -> storeNames.take(3).map { n -> "Marca propia $n" to true }
                else -> listOf(it to false)
            }
        }

    fun parseSize(t: String): Triple<Double, String, String> {
        val m = requireNotNull(sizeRx.matchEntire(t)) { "Tamaño inválido: $t" }
        val n = m.groupValues[1].toDouble()
        val u = m.groupValues[2]
        val pres = m.groupValues[3]
        val (amount, unit) = when (u) {
            "kg" -> n * 1000 to "g"
            "l" -> n * 1000 to "ml"
            else -> n to u
        }
        val presentation = pres.ifBlank { when (unit) { "ml" -> "Botella"; "un" -> "Unidad"; else -> "Paquete" } }
        return Triple(amount, unit, presentation)
    }
}
