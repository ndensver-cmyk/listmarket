@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.mercadolist.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.mercadolist.core.*
import com.mercadolist.data.*

// ---------- Estructura ----------

@Composable
fun AppTopBar(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().background(Yellow).statusBarsPadding().height(56.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Volver", tint = Ink) }
        else Spacer(Modifier.width(12.dp))
        Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        CompositionLocalProvider(LocalContentColor provides Ink) { actions() }
    }
}

@Composable
fun Screen(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    snackbar: SnackbarHostState? = null,
    fab: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = { AppTopBar(title, onBack, actions) },
        floatingActionButton = fab,
        snackbarHost = { if (snackbar != null) SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background,
        content = content
    )
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = modifier.padding(horizontal = 16.dp, vertical = 10.dp))
}

@Composable
fun EmptyState(icon: ImageVector, title: String, text: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.height(4.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        if (action != null) { Spacer(Modifier.height(12.dp)); action() }
    }
}

// ---------- Categorías e imágenes ----------

fun catIcon(name: String): ImageVector = when {
    name.startsWith("Frutas") -> Icons.Filled.Eco
    name.startsWith("Carnes") -> Icons.Filled.Restaurant
    name.startsWith("Lácteos") -> Icons.Filled.Kitchen
    name.startsWith("Bebidas") -> Icons.Filled.LocalCafe
    name.startsWith("Despensa") -> Icons.Filled.Inventory2
    name.startsWith("Panadería") -> Icons.Filled.Cake
    name.startsWith("Snacks") -> Icons.Filled.Fastfood
    name.startsWith("Limpieza") -> Icons.Filled.CleaningServices
    name.startsWith("Aseo") -> Icons.Filled.Spa
    name.startsWith("Mascotas") -> Icons.Filled.Pets
    name.startsWith("Hogar") -> Icons.Filled.Home
    name.startsWith("Congelados") -> Icons.Filled.AcUnit
    name.startsWith("Condimentos") -> Icons.Filled.LocalDining
    name.startsWith("Bebés") -> Icons.Filled.ChildCare
    else -> Icons.Filled.Category
}

private val tileColors = listOf(
    Color(0xFFFFF3B0), Color(0xFFFFE0B2), Color(0xFFD7F0D0), Color(0xFFD6E8FA), Color(0xFFF3D9F5), Color(0xFFFAD4D4), Color(0xFFD9F2EE)
)

fun catColor(categoryId: Long): Color = tileColors[((categoryId.coerceAtLeast(0)) % tileColors.size).toInt()]

private val catEmoji = listOf("🥦", "🥩", "🥛", "🥤", "🍚", "🍞", "🍪", "🧴", "🧼", "🐾", "🏠", "🧊", "🧂", "🍼")

private val emojiRules = listOf(
    "papas fritas" to "🍟", "a la francesa" to "🍟", "banano" to "🍌", "manzana" to "🍎", "naranja" to "🍊", "mango" to "🥭",
    "aguacate" to "🥑", "tomate" to "🍅", "cebolla" to "🧅", "papa" to "🥔", "salchicha" to "🌭", "chorizo" to "🌭",
    "jamon" to "🥓", "tocineta" to "🥓", "mortadela" to "🥓", "pollo" to "🍗", "nuggets" to "🍗", "carne" to "🥩",
    "pescado" to "🐟", "atun" to "🐟", "camaron" to "🦐", "leche" to "🥛", "yogur" to "🥛", "queso" to "🧀",
    "mantequilla" to "🧈", "crema de leche" to "🥛", "huevo" to "🥚", "gaseosa" to "🥤", "jugo" to "🧃", "agua" to "💧",
    "te frio" to "🍵", "energizante" to "⚡", "hidratante" to "🥤", "cafe" to "☕", "chocolat" to "🍫", "arroz" to "🍚",
    "frijol" to "🫘", "lenteja" to "🫘", "garbanzo" to "🫘", "arveja" to "🫘", "azucar" to "🍬", "sal " to "🧂",
    "aceite" to "🫒", "pasta" to "🍝", "harina" to "🌾", "avena" to "🌾", "cereal" to "🥣", "pan " to "🍞", "ponque" to "🍰",
    "levadura" to "🧁", "polvo de hornear" to "🧁", "torta" to "🎂", "arequipe" to "🍯", "mermelada" to "🍓",
    "galleta" to "🍪", "caramelo" to "🍬", "chicle" to "🍬", "gomita" to "🍬", "mani" to "🥜", "barra" to "🍫",
    "snack" to "🍿", "detergente" to "🧺", "suavizante" to "🧺", "blanqueador" to "🧴", "limpiador" to "🧽",
    "lavaplatos" to "🧽", "esponja" to "🧽", "basura" to "🗑️", "insecticida" to "🦟", "shampoo" to "🧴",
    "acondicionador" to "🧴", "jabon" to "🧼", "desodorante" to "🧴", "crema dental" to "🪥", "cepillo" to "🪥",
    "enjuague" to "🪥", "papel higienico" to "🧻", "toallas" to "🌸", "cuchilla" to "🪒", "perro" to "🐶", "gato" to "🐱",
    "mascota" to "🐾", "panales" to "🍼", "toallitas" to "🧻", "formula" to "🍼", "compota" to "🥣", "biberon" to "🍼",
    "bombillo" to "💡", "pilas" to "🔋", "cuaderno" to "📓", "lapiz" to "✏️", "esfero" to "🖊️", "pegante" to "🧴",
    "vasos" to "🥤", "platos" to "🍽️", "aluminio" to "🧻", "servilleta" to "🧻", "pizza" to "🍕", "hamburguesa" to "🍔",
    "helado" to "🍦", "mayonesa" to "🥫", "salsa" to "🥫", "mostaza" to "🥫", "vinagre" to "🥫", "caldo" to "🍲",
    "crema instantanea" to "🍲", "sazonador" to "🧂", "verduras" to "🥦", "ziploc" to "🛍️", "bolsas" to "🛍️"
)

fun productEmoji(name: String, categoryId: Long): String {
    val n = normalize("$name ")
    emojiRules.firstOrNull { n.contains(it.first) }?.let { return it.second }
    return catEmoji.getOrElse((categoryId - 1).toInt()) { "🛒" }
}

@Composable
fun ProductImage(url: String?, brand: String, categoryId: Long, modifier: Modifier = Modifier, name: String = "") {
    val emoji = productEmoji(name, categoryId)
    val placeholder: @Composable () -> Unit = {
        Box(modifier.background(catColor(categoryId)), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 36.sp)
        }
    }
    if (url.isNullOrBlank()) placeholder()
    else SubcomposeAsyncImage(
        model = url, contentDescription = null, modifier = modifier, contentScale = ContentScale.Fit,
        loading = { placeholder() }, error = { placeholder() }
    )
}

// ---------- Etiquetas ----------

@Composable
fun DiscountTag(pct: Int) {
    Text(
        "-$pct %", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(AlertRed).padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun StatusChip(status: PriceStatus) {
    val color = when (status) {
        PriceStatus.COMPROBADO -> OkGreen
        PriceStatus.REGISTRADO -> Color(0xFF1565C0)
        PriceStatus.ESTIMADO -> Color(0xFF5C6BC0)
        PriceStatus.REVISION -> WarnOrange
        PriceStatus.SIN_INFO -> Color(0xFF757575)
    }
    Text(
        status.label, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.12f)).padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun SourceChip(statusName: String) {
    val st = runCatching { StoreSource.valueOf(statusName) }.getOrDefault(StoreSource.PENDIENTE)
    val color = when (st) {
        StoreSource.VERIFICADO -> OkGreen
        StoreSource.MANUAL -> Color(0xFF1565C0)
        StoreSource.IMPORTADO -> Color(0xFF6A1B9A)
        StoreSource.PENDIENTE -> Color(0xFF757575)
    }
    Text(
        st.label, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.12f)).padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

// ---------- Tarjeta de producto ----------

@Composable
fun VariantRowCard(row: VariantRow, onClick: () -> Unit, onAdd: () -> Unit, modifier: Modifier = Modifier) {
    val v = row.view
    val p = row.best
    Card(
        onClick = onClick, modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            ProductImage(v.imageUrl, v.brand, v.categoryId, Modifier.size(76.dp).clip(RoundedCornerShape(10.dp)), v.productName)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(v.fullName, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    "${v.brand} · ${v.presentation} · ${Fmt.content(v.amount, v.unit)}", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (p != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(Fmt.cop(p.price), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = if (p.discountPct != null) AlertRed else MaterialTheme.colorScheme.onSurface)
                        p.originalPrice?.takeIf { p.discountPct != null }?.let {
                            Text(Fmt.cop(it), fontSize = 12.sp, textDecoration = TextDecoration.LineThrough, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        p.discountPct?.let { DiscountTag(it) }
                    }
                    Text(
                        listOfNotNull(Fmt.unitPrice(p.price, v.amount, v.unit), p.storeName, if (p.status == "ESTIMADO") "estimado" else null).joinToString(" · "),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                    )
                } else {
                    Text("Sin precio registrado", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            FilledIconButton(onClick = onAdd, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Yellow, contentColor = Ink)) {
                Icon(Icons.Filled.Add, "Agregar a una lista")
            }
        }
    }
}

// ---------- Entradas ----------

@Composable
fun NumberField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, decimal: Boolean = false) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number)
    )
}

@Composable
fun QtyStepper(qty: Double, onChange: (Double) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { if (qty > 1) onChange(qty - 1) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.Remove, "Menos") }
        Text(Fmt.qty(qty), fontWeight = FontWeight.Bold, modifier = Modifier.widthIn(min = 28.dp))
        IconButton(onClick = { onChange(qty + 1) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.Add, "Más") }
    }
}

@Composable
fun EditAmountDialog(title: String, initial: Long?, onSave: (Long?) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial?.toString() ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = { NumberField(text, { text = it }, "Monto en COP (vacío = sin presupuesto)", Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onSave(text.toMoney()); onDismiss() }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun TextInputDialog(title: String, label: String, initial: String = "", onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onSave(text.trim()); onDismiss() }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ---------- Diálogos compartidos ----------

@Composable
fun AddToListDialog(vm: AppVM, variantId: Long, onDismiss: () -> Unit, onAdded: (String) -> Unit) {
    val lists by vm.lists.collectAsState()
    var sel by remember { mutableStateOf<Long?>(if (lists.isEmpty()) -1L else lists.firstOrNull { it.isActive }?.id) }
    var newName by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Agregar a una lista") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                lists.forEach { l ->
                    Row(Modifier.fillMaxWidth().clickable { sel = l.id }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = sel == l.id, onClick = { sel = l.id })
                        Text(l.name)
                    }
                }
                Row(Modifier.fillMaxWidth().clickable { sel = -1L }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = sel == -1L, onClick = { sel = -1L })
                    Text("Nueva lista")
                }
                if (sel == -1L) OutlinedTextField(newName, { newName = it }, label = { Text("Nombre de la lista") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                NumberField(qty, { qty = it }, "Cantidad", Modifier.fillMaxWidth(), decimal = true)
            }
        },
        confirmButton = {
            TextButton(
                enabled = sel != null && (sel != -1L || newName.isNotBlank()),
                onClick = {
                    val q = qty.toQty()?.takeIf { it > 0 } ?: 1.0
                    val s = sel
                    if (s == -1L) vm.createList(newName) { id -> vm.addVariant(id, variantId, q) }
                    else if (s != null) vm.addVariant(s, variantId, q)
                    onAdded(if (s == -1L) newName else lists.firstOrNull { it.id == s }?.name ?: "la lista")
                    onDismiss()
                }
            ) { Text("Agregar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun ProductPickerDialog(vm: AppVM, onDismiss: () -> Unit, onPick: (VariantView) -> Unit) {
    var query by remember { mutableStateOf("") }
    val rows by remember(query) { vm.search(query, 0L) }.collectAsState(emptyList())
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Elegir producto") },
        text = {
            Column {
                OutlinedTextField(query, { query = it }, label = { Text("Buscar") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 340.dp)) {
                    items(rows.take(60), key = { it.view.variantId }) { r ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(r.view); onDismiss() }.padding(vertical = 8.dp)) {
                            Text(r.view.fullName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${r.view.brand} · ${r.view.presentation}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } }
    )
}

@Composable
fun CustomProductDialog(vm: AppVM, onDismiss: () -> Unit, onCreated: (Long) -> Unit) {
    val cats by vm.categories.collectAsState()
    var name by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var pres by remember { mutableStateOf("Unidad") }
    var amount by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("un") }
    var catId by remember { mutableLongStateOf(0L) }
    LaunchedEffect(cats) { if (catId == 0L && cats.isNotEmpty()) catId = cats.first().id }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Producto personalizado") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(brand, { brand = it }, label = { Text("Marca (opcional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pres, { pres = it }, label = { Text("Presentación") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField(amount, { amount = it }, "Contenido", Modifier.weight(1f), decimal = true)
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("g", "kg", "ml", "L", "un").forEach { u -> FilterChip(selected = unit == u, onClick = { unit = u }, label = { Text(u) }) }
                }
                Text("Categoría", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    cats.forEach { c -> FilterChip(selected = catId == c.id, onClick = { catId = c.id }, label = { Text(c.name) }) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && catId != 0L, onClick = {
                val a = amount.toQty() ?: 1.0
                val (amt, u) = when (unit) { "kg" -> a * 1000 to "g"; "L" -> a * 1000 to "ml"; else -> a to unit }
                vm.createCustomProduct(name.trim(), brand.trim(), catId, pres.trim(), amt, u, onCreated)
                onDismiss()
            }) { Text("Crear") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ---------- Barras simples (distribución de gastos) ----------

private val barColors = listOf(Color(0xFFFFC400), Color(0xFF141414), Color(0xFFE53935), Color(0xFF2E7D32), Color(0xFF1565C0), Color(0xFF6A1B9A), Color(0xFFEF6C00))

@Composable
fun SpendBars(data: List<Pair<String, Double>>) {
    val max = data.maxOfOrNull { it.second }?.takeIf { it > 0 } ?: 1.0
    val total = data.sumOf { it.second }.takeIf { it > 0 } ?: 1.0
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        data.forEachIndexed { i, (label, value) ->
            Column {
                Row {
                    Text(label, Modifier.weight(1f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${Fmt.cop(value)} · ${(value / total * 100).toInt()} %", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                    Box(Modifier.fillMaxWidth((value / max).toFloat().coerceIn(0.02f, 1f)).fillMaxHeight().background(barColors[i % barColors.size]))
                }
            }
        }
    }
}

@Composable
fun InfoCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) { Column(Modifier.padding(14.dp), content = content) }
}
