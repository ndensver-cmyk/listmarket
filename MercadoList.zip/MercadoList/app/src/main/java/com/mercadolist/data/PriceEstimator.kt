package com.mercadolist.data

import kotlin.math.pow
import kotlin.math.roundToLong

data class ModelEntry(
    val base: Double,
    val exp: Double,
    val variantFactors: Map<String, Double>,
    val presentationFactors: Map<String, Double>
)

/**
 * Precio ESTIMADO (promedio de referencia) por supermercado. No es una cotización:
 * se calcula desde un precio base por kg/L/unidad, el tamaño, la variante, la marca y la tienda.
 * Las marcas propias solo existen en su propia tienda.
 */
object PriceEstimator {
    val storeFactors = mapOf("D1" to 0.94, "Ara" to 0.96, "Olímpica" to 1.00, "Éxito" to 1.03, "Jumbo" to 1.05, "Carulla" to 1.09)

    fun parse(lines: List<String>): Map<String, ModelEntry> {
        val out = HashMap<String, ModelEntry>()
        for (raw in lines) {
            val l = raw.trim()
            if (l.isEmpty() || l.startsWith("#")) continue
            val p = l.split("|")
            require(p.size >= 3) { "Línea de precios inválida: $l" }
            out["${p[0]}|${p[1]}"] = ModelEntry(
                base = p[2].trim().toDouble(),
                exp = p.getOrNull(3)?.trim()?.takeIf { it.isNotEmpty() }?.toDouble() ?: 0.08,
                variantFactors = factors(p.getOrNull(4)),
                presentationFactors = factors(p.getOrNull(5))
            )
        }
        return out
    }

    private fun factors(s: String?): Map<String, Double> {
        if (s.isNullOrBlank()) return emptyMap()
        return s.split(";").mapNotNull { part ->
            val kv = part.split("=")
            if (kv.size == 2) kv[0].trim() to kv[1].trim().toDouble() else null
        }.toMap()
    }

    fun estimate(e: ModelEntry, amount: Double, unit: String, label: String, presentation: String, brand: String, store: String, sku: String): Long? {
        val isStoreBrand = brand.startsWith("Marca propia ")
        if (isStoreBrand && brand != "Marca propia $store") return null
        val units = if (unit == "un") amount else amount / 1000.0
        val presF = e.presentationFactors[presentation]
        val core = if (presF != null) e.base * presF else e.base * units * units.pow(-e.exp)
        val variantF = e.variantFactors[label] ?: 1.0
        val brandF = if (isStoreBrand) 0.80 else 0.95 + ((brand.hashCode() and 0x7fffffff) % 11) / 100.0
        val storeF = if (isStoreBrand) 1.0 else (storeFactors[store] ?: 1.0) * (0.97 + (((sku + store).hashCode() and 0x7fffffff) % 7) / 100.0)
        val raw = core * variantF * brandF * storeF
        return ((raw / 50.0).roundToLong() * 50).coerceAtLeast(50)
    }
}
