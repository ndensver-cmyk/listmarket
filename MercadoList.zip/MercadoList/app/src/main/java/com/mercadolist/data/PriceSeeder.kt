package com.mercadolist.data

import android.content.Context
import androidx.room.withTransaction
import com.mercadolist.core.StoreSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

/** Siembra una sola vez: precios estimados por tienda + los precios reales conocidos (real_prices.txt). */
class PriceSeeder(private val db: AppDb, private val ctx: Context, private val settings: SettingsStore) {

    suspend fun seedIfNeeded() = withContext(Dispatchers.IO) {
        if (settings.pricesSeeded()) return@withContext
        val model = PriceEstimator.parse(ctx.assets.open("price_model.txt").bufferedReader().use { it.readLines() })
        val realLines = ctx.assets.open("real_prices.txt").bufferedReader().use { it.readLines() }
        val now = System.currentTimeMillis()

        db.withTransaction {
            val pd = db.price()
            val cd = db.catalog()
            val estName = "Estimado (promedio de referencia)"
            if (pd.sources().none { it.name == estName })
                pd.insertSources(listOf(PriceSourceEntity(name = estName, evidence = "Calculado con un precio base de referencia; no es una cotización")))
            val stores = pd.storesOnce().filter { !it.isCustom }

            val estSource = pd.sources().first { it.name == estName }.id
            val batch = ArrayList<PriceEntity>(4000)
            for (v in cd.allVariants()) {
                val m = model["${v.categoryName}|${v.productName}"] ?: continue
                for (s in stores) {
                    val price = PriceEstimator.estimate(m, v.amount, v.unit, v.label, v.presentation, v.brand, s.name, v.sku) ?: continue
                    batch += PriceEntity(
                        variantId = v.variantId, storeId = s.id, price = price, city = "Referencia nacional",
                        sourceId = estSource, consultedAt = now, status = "ESTIMADO"
                    )
                    if (batch.size >= 4000) { pd.insertPrices(batch.toList()); batch.clear() }
                }
            }
            if (batch.isNotEmpty()) pd.insertPrices(batch.toList())

            // Precios reales (los más recientes ganan sobre los estimados)
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            for (raw in realLines) {
                val l = raw.trim()
                if (l.isEmpty() || l.startsWith("#")) continue
                val c = l.split("|").map { it.trim() }
                if (c.size < 9) continue
                val store = stores.firstOrNull { it.name == c[0] } ?: continue
                val (amount, unit, _) = CatalogGenerator.parseSize(c[4])
                val vid = cd.variantIdByRef(c[1], c[2], c[3], amount, unit) ?: continue
                if (pd.sources().none { it.name == c[8] }) pd.insertSources(listOf(PriceSourceEntity(name = c[8], evidence = "Precio publicado por la tienda")))
                val src = pd.sources().first { it.name == c[8] }.id
                pd.insertPrice(
                    PriceEntity(
                        variantId = vid, storeId = store.id, price = c[5].toLong(), originalPrice = c[6].toLongOrNull(),
                        city = "Precio publicado", sourceId = src, consultedAt = (fmt.parse(c[7])?.time ?: now) + 12 * 3600_000L,
                        status = "COMPROBADO"
                    )
                )
                pd.updateStore(store.copy(sourceStatus = StoreSource.IMPORTADO.name))
            }
        }
        settings.setPricesSeeded()
    }
}
