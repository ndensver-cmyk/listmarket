package com.mercadolist.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "brands", indices = [Index(value = ["name"], unique = true)])
data class BrandEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isStoreBrand: Boolean = false
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val code: String
)

/** Familia de producto (nombre + marca + categoría). Las referencias están en product_variants. */
@Entity(tableName = "products", indices = [Index("categoryId"), Index("brandId")])
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val brandId: Long,
    val categoryId: Long,
    val subcategory: String,
    val description: String = "",
    val imageUrl: String? = null,
    val isCustom: Boolean = false,
    @ColumnInfo(defaultValue = "0") val photoTried: Boolean = false
)

/** Referencia específica: sabor/variante + presentación + contenido. */
@Entity(tableName = "product_variants", indices = [Index("productId"), Index(value = ["sku"], unique = true)])
data class VariantEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val sku: String,
    val label: String,
    val presentation: String,
    val amount: Double,
    val unit: String,
    val available: Boolean = true,
    val imageUrl: String? = null,
    val search: String = ""
)

@Entity(tableName = "barcodes", indices = [Index("variantId")])
data class BarcodeEntity(@PrimaryKey val ean: String, val variantId: Long)

@Entity(tableName = "stores")
data class StoreEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isCustom: Boolean = false,
    val sourceStatus: String = "PENDIENTE",
    val transportCost: Long = 0,
    val deliveryCost: Long = 0
)

@Entity(tableName = "store_branches", indices = [Index("storeId")])
data class StoreBranchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val storeId: Long,
    val city: String,
    val address: String = ""
)

@Entity(tableName = "price_sources")
data class PriceSourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val evidence: String = ""
)

@Entity(tableName = "prices", indices = [Index("variantId"), Index("storeId")])
data class PriceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val variantId: Long,
    val storeId: Long,
    val price: Long,
    val originalPrice: Long? = null,
    val city: String,
    val sourceId: Long,
    val consultedAt: Long,
    val status: String,
    val inStock: Boolean = true
)

@Entity(tableName = "shopping_lists")
data class ShoppingListEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val isTemplate: Boolean = false,
    val isActive: Boolean = false,
    val budget: Long? = null,
    val completedAt: Long? = null
)

@Entity(tableName = "shopping_list_items", indices = [Index("listId")])
data class ListItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val listId: Long,
    val variantId: Long? = null,
    val customName: String? = null,
    val categoryId: Long = 0,
    val quantity: Double = 1.0,
    val unitPrice: Long? = null,
    val purchased: Boolean = false,
    val note: String = ""
)

@Entity(tableName = "budgets", indices = [Index(value = ["period", "categoryId"], unique = true)])
data class BudgetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val period: String,
    val categoryId: Long, // 0 = presupuesto general
    val amount: Long
)

@Entity(tableName = "purchases")
data class PurchaseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val date: Long,
    val total: Long,
    val storeName: String = ""
)

@Entity(tableName = "purchase_items", indices = [Index("purchaseId")])
data class PurchaseItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseId: Long,
    val variantId: Long?,
    val name: String,
    val categoryId: Long,
    val quantity: Double,
    val unitPrice: Long
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val variantId: Long)

@Entity(tableName = "inventory")
data class InventoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long? = null,
    val name: String,
    val quantity: Double,
    val unit: String
)
