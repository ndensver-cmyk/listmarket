package com.mercadolist.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.mercadolist.core.PriceStatus
import com.mercadolist.core.STALE_MS
import kotlinx.coroutines.flow.Flow

// ---------- Vistas de lectura ----------

data class VariantView(
    val variantId: Long, val productId: Long, val sku: String, val productName: String, val brand: String,
    val categoryId: Long, val categoryName: String, val subcategory: String, val label: String,
    val presentation: String, val amount: Double, val unit: String, val imageUrl: String?,
    val available: Boolean, val description: String
) {
    val fullName: String get() = if (label.isBlank()) productName else "$productName $label"
}

data class PriceView(
    val priceId: Long, val variantId: Long, val storeId: Long, val storeName: String, val price: Long,
    val originalPrice: Long?, val city: String, val sourceName: String, val consultedAt: Long,
    val status: String, val inStock: Boolean
) {
    fun effective(now: Long = System.currentTimeMillis()): PriceStatus =
        if (now - consultedAt > STALE_MS) PriceStatus.REVISION
        else runCatching { PriceStatus.valueOf(status) }.getOrDefault(PriceStatus.REVISION)

    /** Vigente = disponible y con menos de 30 días. Un precio antiguo NUNCA se presenta como actual. */
    fun isCurrent(now: Long = System.currentTimeMillis()): Boolean = inStock && effective(now) != PriceStatus.REVISION

    val discountPct: Int? get() = originalPrice?.takeIf { it > price }?.let { ((it - price) * 100 / it).toInt() }
}

data class ItemView(
    val id: Long, val listId: Long, val variantId: Long?, val productId: Long?, val name: String,
    val brand: String?, val presentation: String?, val amount: Double?, val unit: String?,
    val categoryId: Long, val quantity: Double, val unitPrice: Long?, val purchased: Boolean, val note: String
)

data class ListSummary(val listId: Long, val itemCount: Int, val total: Double)
data class CategorySpend(val categoryId: Long, val total: Double)

const val VARIANT_SELECT =
    "SELECT v.id AS variantId, p.id AS productId, v.sku AS sku, p.name AS productName, b.name AS brand, " +
    "p.categoryId AS categoryId, c.name AS categoryName, p.subcategory AS subcategory, v.label AS label, " +
    "v.presentation AS presentation, v.amount AS amount, v.unit AS unit, COALESCE(v.imageUrl, p.imageUrl) AS imageUrl, " +
    "v.available AS available, p.description AS description " +
    "FROM product_variants v JOIN products p ON p.id = v.productId JOIN brands b ON b.id = p.brandId " +
    "JOIN categories c ON c.id = p.categoryId"

const val PRICE_SELECT =
    "SELECT pr.id AS priceId, pr.variantId AS variantId, pr.storeId AS storeId, s.name AS storeName, pr.price AS price, " +
    "pr.originalPrice AS originalPrice, pr.city AS city, src.name AS sourceName, pr.consultedAt AS consultedAt, " +
    "pr.status AS status, pr.inStock AS inStock " +
    "FROM prices pr JOIN stores s ON s.id = pr.storeId JOIN price_sources src ON src.id = pr.sourceId"

const val PRICE_LATEST = PRICE_SELECT +
    " WHERE pr.consultedAt = (SELECT MAX(p2.consultedAt) FROM prices p2 WHERE p2.variantId = pr.variantId " +
    "AND p2.storeId = pr.storeId AND p2.city = pr.city)"

const val ITEM_SELECT =
    "SELECT i.id AS id, i.listId AS listId, i.variantId AS variantId, p.id AS productId, " +
    "COALESCE(p.name || CASE WHEN v.label <> '' THEN ' ' || v.label ELSE '' END, i.customName, 'Producto') AS name, " +
    "b.name AS brand, v.presentation AS presentation, v.amount AS amount, v.unit AS unit, " +
    "COALESCE(p.categoryId, i.categoryId) AS categoryId, i.quantity AS quantity, i.unitPrice AS unitPrice, " +
    "i.purchased AS purchased, i.note AS note " +
    "FROM shopping_list_items i LEFT JOIN product_variants v ON v.id = i.variantId " +
    "LEFT JOIN products p ON p.id = v.productId LEFT JOIN brands b ON b.id = p.brandId"

// ---------- DAOs ----------

@Dao
interface CatalogDao {
    @Insert suspend fun insertCategories(list: List<CategoryEntity>): List<Long>
    @Insert suspend fun insertBrands(list: List<BrandEntity>): List<Long>
    @Insert suspend fun insertBrand(b: BrandEntity): Long
    @Insert suspend fun insertProducts(list: List<ProductEntity>): List<Long>
    @Insert suspend fun insertProduct(p: ProductEntity): Long
    @Insert suspend fun insertVariants(list: List<VariantEntity>): List<Long>
    @Insert suspend fun insertVariant(v: VariantEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertBarcode(b: BarcodeEntity)

    @Query("SELECT COUNT(*) FROM product_variants") suspend fun variantCount(): Int
    @Query("SELECT COUNT(*) FROM product_variants") fun variantCountFlow(): Flow<Int>
    @Query("SELECT * FROM categories ORDER BY id") fun categories(): Flow<List<CategoryEntity>>
    @Query("SELECT * FROM brands WHERE name = :name LIMIT 1") suspend fun brandByName(name: String): BrandEntity?

    @Query(VARIANT_SELECT + " WHERE (:cat = 0 OR p.categoryId = :cat) AND v.search LIKE :pattern ORDER BY p.name, b.name, v.amount LIMIT :limit")
    fun search(pattern: String, cat: Long, limit: Int): Flow<List<VariantView>>

    @Query(VARIANT_SELECT + " WHERE v.id = :id") suspend fun variant(id: Long): VariantView?
    @Query(VARIANT_SELECT + " WHERE v.id IN (:ids)") suspend fun variants(ids: List<Long>): List<VariantView>
    @Query(VARIANT_SELECT + " WHERE p.id = :productId ORDER BY v.amount, v.label") suspend fun variantsOfProduct(productId: Long): List<VariantView>

    @Query(VARIANT_SELECT + " WHERE p.categoryId = :cat AND p.subcategory = :sub AND p.id <> :productId " +
        "ORDER BY (p.name = :name) DESC, ABS(v.amount - :amount) LIMIT 12")
    suspend fun substitutes(cat: Long, sub: String, productId: Long, name: String, amount: Double): List<VariantView>

    @Query("SELECT variantId FROM barcodes WHERE ean = :ean") suspend fun variantIdByEan(ean: String): Long?
    @Query("SELECT ean FROM barcodes WHERE variantId = :variantId") suspend fun barcodesOf(variantId: Long): List<String>
    @Query("SELECT id FROM product_variants WHERE sku = :sku LIMIT 1") suspend fun variantIdBySku(sku: String): Long?
    @Query("UPDATE product_variants SET imageUrl = :url WHERE id = :id") suspend fun setVariantImage(id: Long, url: String)
}

@Dao
interface PriceDao {
    @Insert suspend fun insertStores(list: List<StoreEntity>): List<Long>
    @Insert suspend fun insertStore(s: StoreEntity): Long
    @Update suspend fun updateStore(s: StoreEntity)
    @Query("SELECT * FROM stores ORDER BY isCustom, name") fun stores(): Flow<List<StoreEntity>>
    @Query("SELECT * FROM stores") suspend fun storesOnce(): List<StoreEntity>
    @Query("SELECT * FROM stores WHERE id = :id") suspend fun storeById(id: Long): StoreEntity?
    @Query("SELECT * FROM stores WHERE LOWER(name) = LOWER(:name) LIMIT 1") suspend fun storeByName(name: String): StoreEntity?

    @Insert suspend fun insertBranch(b: StoreBranchEntity)
    @Query("SELECT * FROM store_branches ORDER BY city") fun branches(): Flow<List<StoreBranchEntity>>

    @Insert suspend fun insertSources(list: List<PriceSourceEntity>): List<Long>
    @Query("SELECT * FROM price_sources") suspend fun sources(): List<PriceSourceEntity>

    @Insert suspend fun insertPrice(p: PriceEntity): Long

    @Query(PRICE_LATEST + " AND pr.variantId = :variantId ORDER BY pr.price") fun latestForVariant(variantId: Long): Flow<List<PriceView>>
    @Query(PRICE_LATEST + " AND pr.variantId IN (:ids)") suspend fun latestForVariants(ids: List<Long>): List<PriceView>
    @Query(PRICE_LATEST + " AND pr.originalPrice IS NOT NULL AND pr.originalPrice > pr.price " +
        "ORDER BY (pr.originalPrice - pr.price) * 1.0 / pr.originalPrice DESC LIMIT 30")
    fun promotions(): Flow<List<PriceView>>
    @Query(PRICE_SELECT + " WHERE pr.variantId = :variantId ORDER BY pr.consultedAt") fun history(variantId: Long): Flow<List<PriceView>>
}

@Dao
interface ListDao {
    @Insert suspend fun insertList(l: ShoppingListEntity): Long
    @Update suspend fun updateList(l: ShoppingListEntity)
    @Query("SELECT * FROM shopping_lists WHERE isTemplate = 0 AND completedAt IS NULL ORDER BY updatedAt DESC") fun lists(): Flow<List<ShoppingListEntity>>
    @Query("SELECT * FROM shopping_lists WHERE isTemplate = 1 ORDER BY updatedAt DESC") fun templates(): Flow<List<ShoppingListEntity>>
    @Query("SELECT * FROM shopping_lists WHERE id = :id") fun list(id: Long): Flow<ShoppingListEntity?>
    @Query("SELECT * FROM shopping_lists WHERE id = :id") suspend fun listOnce(id: Long): ShoppingListEntity?
    @Query("SELECT * FROM shopping_lists WHERE isActive = 1 AND completedAt IS NULL LIMIT 1") fun activeList(): Flow<ShoppingListEntity?>
    @Query("UPDATE shopping_lists SET isActive = 0") suspend fun clearActive()
    @Query("DELETE FROM shopping_lists WHERE id = :id") suspend fun deleteList(id: Long)
    @Query("DELETE FROM shopping_list_items WHERE listId = :id") suspend fun deleteItemsOf(id: Long)

    @Insert suspend fun insertItem(i: ListItemEntity): Long
    @Update suspend fun updateItem(i: ListItemEntity)
    @Query("DELETE FROM shopping_list_items WHERE id = :id") suspend fun deleteItem(id: Long)
    @Query("SELECT * FROM shopping_list_items WHERE id = :id") suspend fun itemById(id: Long): ListItemEntity?
    @Query("SELECT * FROM shopping_list_items WHERE listId = :listId") suspend fun itemsOnce(listId: Long): List<ListItemEntity>
    @Query(ITEM_SELECT + " WHERE i.listId = :listId ORDER BY i.purchased, i.id") fun items(listId: Long): Flow<List<ItemView>>
    @Query(ITEM_SELECT + " WHERE i.listId = :listId ORDER BY i.purchased, i.id") suspend fun itemViewsOnce(listId: Long): List<ItemView>

    @Query("SELECT listId AS listId, COUNT(*) AS itemCount, COALESCE(SUM(quantity * COALESCE(unitPrice, 0)), 0.0) AS total " +
        "FROM shopping_list_items GROUP BY listId")
    fun summaries(): Flow<List<ListSummary>>

    @Query("SELECT COALESCE(SUM(i.quantity * COALESCE(i.unitPrice, 0)), 0.0) FROM shopping_list_items i " +
        "JOIN shopping_lists l ON l.id = i.listId WHERE l.isActive = 1 AND l.completedAt IS NULL AND i.purchased = 0")
    fun pendingTotal(): Flow<Double>
}

@Dao
interface FinanceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertBudget(b: BudgetEntity)
    @Query("SELECT * FROM budgets WHERE period = :period") fun budgets(period: String): Flow<List<BudgetEntity>>
    @Query("DELETE FROM budgets WHERE period = :period AND categoryId = :cat") suspend fun deleteBudget(period: String, cat: Long)

    @Insert suspend fun insertPurchase(p: PurchaseEntity): Long
    @Insert suspend fun insertPurchaseItems(list: List<PurchaseItemEntity>)
    @Query("SELECT * FROM purchases ORDER BY date DESC") fun purchases(): Flow<List<PurchaseEntity>>
    @Query("SELECT * FROM purchase_items WHERE purchaseId = :id") suspend fun purchaseItems(id: Long): List<PurchaseItemEntity>
    @Query("DELETE FROM purchases WHERE id = :id") suspend fun deletePurchase(id: Long)
    @Query("DELETE FROM purchase_items WHERE purchaseId = :id") suspend fun deletePurchaseItems(id: Long)

    @Query("SELECT pi.categoryId AS categoryId, COALESCE(SUM(pi.quantity * pi.unitPrice), 0.0) AS total " +
        "FROM purchase_items pi JOIN purchases pu ON pu.id = pi.purchaseId WHERE pu.date BETWEEN :fromMs AND :toMs GROUP BY pi.categoryId")
    fun spendByCategory(fromMs: Long, toMs: Long): Flow<List<CategorySpend>>

    @Query("SELECT COALESCE(SUM(total), 0) FROM purchases WHERE date BETWEEN :fromMs AND :toMs")
    fun spent(fromMs: Long, toMs: Long): Flow<Long>
}

@Dao
interface PersonalDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addFavorite(f: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE variantId = :id") suspend fun removeFavorite(id: Long)
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE variantId = :id)") fun isFavorite(id: Long): Flow<Boolean>
    @Query(VARIANT_SELECT + " WHERE v.id IN (SELECT variantId FROM favorites) ORDER BY p.name") fun favorites(): Flow<List<VariantView>>

    @Query("SELECT * FROM inventory ORDER BY name") fun inventory(): Flow<List<InventoryEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertInventory(i: InventoryEntity)
    @Delete suspend fun deleteInventory(i: InventoryEntity)
}
