@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.mercadolist.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mercadolist.core.*

@Composable
fun CompareScreen(vm: AppVM, nav: NavController, listId: Long) {
    var includeStale by remember { mutableStateOf(false) }
    var delivery by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CompareResult?>(null) }
    LaunchedEffect(listId, includeStale, delivery) { result = vm.compare(listId, includeStale, delivery) }
    val r = result

    Screen(title = "Comparar supermercados", onBack = { nav.popBackStack() }) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                InfoCard {
                    Text("¿Cómo vas a comprar?", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = !delivery, onClick = { delivery = false }, label = { Text("Voy a la tienda") })
                        FilterChip(selected = delivery, onClick = { delivery = true }, label = { Text("Domicilio") })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = includeStale, onCheckedChange = { includeStale = it })
                        Spacer(Modifier.width(8.dp))
                        Text("Incluir precios con más de 30 días", fontSize = 13.sp)
                    }
                    Text("Se comparan productos del catálogo con precio vigente y existencias. Los marcados como estimados son promedios de referencia, no cotizaciones; los precios reales siempre tienen prioridad. Los costos de transporte y domicilio se editan en Supermercados.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (r == null) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
            else if (r.totals.isEmpty()) item {
                EmptyState(
                    Icons.Filled.SwapHoriz, "No hay precios para comparar",
                    "Ningún supermercado tiene precios vigentes para los productos pendientes de esta lista. Registra precios en la ficha de cada producto o importa un CSV.",
                    action = { Button(onClick = { nav.navigate("stores") }, colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Ink)) { Text("Ir a supermercados") } }
                )
            } else {
                // B. Lista completa por supermercado
                item { Text("Total de la lista por supermercado", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                items(r.totals, key = { it.store.id }) { t ->
                    val isBest = t == r.bestSingle
                    InfoCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t.store.name, fontWeight = FontWeight.Bold)
                                SourceChip(t.store.sourceStatus)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(Fmt.cop(t.total), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = if (isBest) OkGreen else MaterialTheme.colorScheme.onSurface)
                                if (t.extra > 0) Text("+ ${Fmt.cop(t.extra)} ${if (delivery) "domicilio" else "transporte"}", fontSize = 11.sp)
                            }
                        }
                        if (t.missing > 0) Text("Faltan ${t.missing} de ${r.itemCount} productos (sin precio vigente en esta tienda): el total no es comparable.", fontSize = 12.sp, color = WarnOrange)
                        else Text(if (isBest) "Mejor opción en una sola tienda" else "Lista completa", fontSize = 12.sp, color = if (isBest) OkGreen else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                // C. Distribuir compras
                item { Text("Distribuir las compras", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                items(r.distribution, key = { it.first.id }) { (store, assigns) ->
                    InfoCard {
                        Text(store.name, fontWeight = FontWeight.Bold)
                        assigns.forEach { a ->
                            Row(Modifier.padding(top = 4.dp)) {
                                Text("${Fmt.qty(a.item.quantity)} × ${a.item.name}", Modifier.weight(1f), fontSize = 13.sp)
                                Text(Fmt.cop(a.price.price * a.item.quantity), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                item {
                    InfoCard {
                        Text("Resultado", fontWeight = FontWeight.Bold)
                        Row { Text("Comprando en varias tiendas", Modifier.weight(1f)); Text(Fmt.cop(r.distTotal), fontWeight = FontWeight.Bold) }
                        Row { Text("Costos adicionales (${r.distribution.size} tiendas)", Modifier.weight(1f)); Text(Fmt.cop(r.distExtra), fontWeight = FontWeight.Bold) }
                        HorizontalDivider(Modifier.padding(vertical = 6.dp))
                        Row { Text("Total", Modifier.weight(1f), fontWeight = FontWeight.Bold); Text(Fmt.cop(r.distTotal + r.distExtra), fontWeight = FontWeight.ExtraBold) }
                        val s = r.savings
                        Spacer(Modifier.height(6.dp))
                        if (s == null) Text("No hay una tienda con todos los productos, así que no se puede medir el ahorro frente a comprar en un solo lugar.", fontSize = 12.sp)
                        else if (s > 0) Text("Ahorras ${Fmt.cop(s)} frente a la mejor tienda única (${r.bestSingle?.store?.name}). Sí vale la pena repartir.", color = OkGreen, fontWeight = FontWeight.SemiBold)
                        else Text("Comprar todo en ${r.bestSingle?.store?.name} cuesta igual o menos una vez sumados transporte y domicilio. No compensa repartir.", color = WarnOrange, fontWeight = FontWeight.SemiBold)
                    }
                }
                if (r.noPrice.isNotEmpty()) item {
                    InfoCard {
                        Text("Sin precio vigente en ninguna tienda", fontWeight = FontWeight.Bold)
                        r.noPrice.forEach { Text("• ${it.name}", fontSize = 13.sp) }
                    }
                }
                if (r.staleSkipped > 0) item { Text("${r.staleSkipped} precios antiguos (más de 30 días) se dejaron fuera. Actívalos arriba si quieres verlos.", fontSize = 12.sp, color = WarnOrange) }
            }
        }
    }
}
