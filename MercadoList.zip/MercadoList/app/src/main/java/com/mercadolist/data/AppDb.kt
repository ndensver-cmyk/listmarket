package com.mercadolist.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        BrandEntity::class, CategoryEntity::class, ProductEntity::class, VariantEntity::class, BarcodeEntity::class,
        StoreEntity::class, StoreBranchEntity::class, PriceSourceEntity::class, PriceEntity::class,
        ShoppingListEntity::class, ListItemEntity::class, BudgetEntity::class, PurchaseEntity::class,
        PurchaseItemEntity::class, FavoriteEntity::class, InventoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun catalog(): CatalogDao
    abstract fun price(): PriceDao
    abstract fun lists(): ListDao
    abstract fun finance(): FinanceDao
    abstract fun personal(): PersonalDao
}
