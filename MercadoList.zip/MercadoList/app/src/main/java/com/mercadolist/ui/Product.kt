@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.mercadolist.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mercadolist.core.*
import com.mercadolist.data.*
import kotlinx.coroutines.launch

@Composable
fun ProductScreen(vm: AppVM, nav: NavController, variantId: Long) {
    var v by remember(variantId) { mutableStateOf<VariantView?>(null) }
    var siblings by remember(variantId) { mutableStateOf<List<VariantView>>(emptyList()) }
    var subs by remember(variantId) { mutableStateOf<List<VariantRow>>(emptyList()) }
    var codes by remember(variantId) { mutableStateOf<List<String>>(emptyList()) }
    LaunchedEffect(variantId) {
        val loaded = vm.variant(variantId)
        v = loaded
        codes = vm.barcodes(variantId)
        if (loaded != null) {
            siblings = vm.variantsOfProduct(loaded.productId).filter { it.variantId != variantId }
            subs = vm.substitutes(loaded)
        }
    }
    val prices by remember(variantId) { vm.prices(variantId) }.collectAsState(emptyList())
    val history by remember(variantId) { vm.history(variantId) }.collectAsState(emptyList())
    val fav by remember(variantId) { vm.isFavorite(variantId) }.collectAsState(false)
    val stores by vm.stores.collectAsState()
    val st by vm.settings.collectAsState()
    var addDialog by remember { mutableStateOf(false) }
    var priceDialog by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val now = System.currentTimeMillis()

    Screen(
        title = "Producto", onBack = { nav.popBackStack() }, snackbar = snack,
        actions = {
            IconButton(onClick = { vm.toggleFavorite(variantId, fav) }) {
                Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favorito", tint = if (fav) AlertRed else Ink)
            }
        }
    ) { pad ->
        val p = v
        if (p == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Screen
        }
        val current = prices.filter { it.isCurrent(now) }
        val best = current.minByOrNull { it.price }
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                ProductImage(p.imageUrl, p.brand, p.categoryId, Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(16.dp)))
                Spacer(Modifier.height(10.dp))
                Text(p.brand, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(p.fullName, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("${p.presentation} · ${Fmt.content(p.amount, p.unit)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                InfoCard {
                    if (best != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(Fmt.cop(best.price), fontWeight = FontWeight.ExtraBold, fontSize = 28.sp, color = if (best.discountPct != null) AlertRed else MaterialTheme.colorScheme.onSurface)
                            best.originalPrice?.takeIf { best.discountPct != null }?.let { Text(Fmt.cop(it), textDecoration = TextDecoration.LineThrough, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            best.discountPct?.let { DiscountTag(it) }
                        }
                        Fmt.unitPrice(best.price, p.amount, p.unit)?.let { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Text("Mejor precio vigente en ${best.storeName} · actualizado ${Fmt.date(best.consultedAt)}", fontSize = 12.sp)
                    } else {
                        Text("Sin precio vigente", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            if (prices.isEmpty()) "Nadie ha registrado un precio de este producto todavía." else "Los precios registrados tienen más de 30 días y necesitan revisión.",
                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { addDialog = true }, colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Ink)) {
                            Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text("A una lista")
                        }
                        OutlinedButton(onClick = { priceDialog = true }) { Icon(Icons.Filled.Edit, null); Spacer(Modifier.width(4.dp)); Text("Registrar precio") }
                    }
                }
            }
            item {
                InfoCard {
                    Text("Ficha técnica", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    listOf(
                        "SKU" to p.sku,
                        "Categoría" to "${p.categoryName} › ${p.subcategory}",
                        "Marca" to p.brand,
                        "Presentación" to p.presentation,
                        "Contenido" to Fmt.content(p.amount, p.unit),
                        "Disponibilidad" to if (p.available) "Disponible" else "No disponible",
                        "Código de barras" to (if (codes.isEmpty()) "Sin registrar (escanéalo para vincularlo)" else codes.joinToString())
                    ).forEach { (k, value) ->
                        Row(Modifier.padding(vertical = 3.dp)) {
                            Text(k, Modifier.weight(0.4f), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(value, Modifier.weight(0.6f), fontSize = 13.sp)
                        }
                    }
                    if (p.description.isNotBlank()) Text(p.description, fontSize = 13.sp)
                }
            }
            item { Text("Precios por supermercado", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            if (prices.isEmpty()) item {
                Text("Ningún supermercado tiene precio registrado. Los precios nunca se inventan: regístralos tú o importa un CSV.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(prices, key = { it.priceId }) { pr ->
                InfoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(pr.storeName, fontWeight = FontWeight.SemiBold)
                            Text("${pr.city} · ${pr.sourceName} · ${Fmt.date(pr.consultedAt)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(Fmt.cop(pr.price), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Fmt.unitPrice(pr.price, p.amount, p.unit)?.let { Text(it, fontSize = 11.sp) }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        StatusChip(pr.effective(now))
                        if (!pr.inStock) Text("Agotado", color = AlertRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    if (!pr.isCurrent(now) && pr.effective(now) == PriceStatus.REVISION)
                        Text("Precio antiguo: no se usa como precio actual ni en las comparaciones.", fontSize = 11.sp, color = WarnOrange)
                }
            }
            if (history.size > 1) {
                item { Text("Historial de precios", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                val byStore = history.groupBy { it.storeName }
                items(byStore.entries.toList(), key = { it.key }) { (store, list) ->
                    InfoCard {
                        Text(store, fontWeight = FontWeight.SemiBold)
                        if (list.size >= 2) PriceChart(list.map { it.consultedAt to it.price }, Modifier.fillMaxWidth().height(90.dp).padding(vertical = 6.dp))
                        Text(list.takeLast(6).joinToString("  ·  ") { "${Fmt.date(it.consultedAt)}: ${Fmt.cop(it.price)}" }, fontSize = 11.sp)
                    }
                }
            }
            if (siblings.isNotEmpty()) {
                item { Text("Otras presentaciones y variantes", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(siblings, key = { it.variantId }) { s ->
                            AssistChip(onClick = { nav.navigate("product/${s.variantId}") }, label = { Text("${s.label.ifBlank { s.presentation }} · ${Fmt.content(s.amount, s.unit)}") })
                        }
                    }
                }
            }
            if (subs.isNotEmpty()) {
                item { Text("Productos sustitutos", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(subs, key = { it.view.variantId }) { r ->
                            Card(onClick = { nav.navigate("product/${r.view.variantId}") }, modifier = Modifier.width(150.dp), shape = RoundedCornerShape(14.dp)) {
                                Column(Modifier.padding(8.dp)) {
                                    ProductImage(r.view.imageUrl, r.view.brand, r.view.categoryId, Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(10.dp)))
                                    Text(r.view.fullName, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                    Text("${r.view.brand} · ${Fmt.content(r.view.amount, r.view.unit)}", fontSize = 11.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(r.best?.let { Fmt.cop(it.price) } ?: "Sin precio", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (addDialog) AddToListDialog(vm, variantId, onDismiss = { addDialog = false }, onAdded = { n -> scope.launch { snack.showSnackbar("Agregado a $n") } })
        if (priceDialog) RegisterPriceDialog(vm, variantId, stores, st.city, onDismiss = { priceDialog = false })
    }
}

@Composable
private fun RegisterPriceDialog(vm: AppVM, variantId: Long, stores: List<StoreEntity>, defaultCity: String, onDismiss: () -> Unit) {
    var storeId by remember { mutableLongStateOf(stores.firstOrNull()?.id ?: 0L) }
    var price by remember { mutableStateOf("") }
    var original by remember { mutableStateOf("") }
    var city by remember { mutableStateOf(defaultCity) }
    var inStock by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Registrar precio") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Supermercado", fontWeight = FontWeight.SemiBold)
                stores.forEach { s ->
                    Row(Modifier.fillMaxWidth().clickable { storeId = s.id }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = storeId == s.id, onClick = { storeId = s.id }); Text(s.name)
                    }
                }
                NumberField(price, { price = it }, "Precio actual (COP)", Modifier.fillMaxWidth())
                NumberField(original, { original = it }, "Precio anterior si hay descuento (opcional)", Modifier.fillMaxWidth())
                OutlinedTextField(city, { city = it }, label = { Text("Ciudad") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(checked = inStock, onCheckedChange = { inStock = it }); Spacer(Modifier.width(8.dp)); Text("Hay existencias") }
                Text("Se guarda con la fecha de hoy y la fuente \"Registrado por el usuario\".", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(enabled = storeId != 0L && (price.toMoney() ?: 0L) > 0, onClick = {
                vm.registerPrice(variantId, storeId, price.toMoney()!!, original.toMoney(), city, inStock); onDismiss()
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun PriceChart(points: List<Pair<Long, Long>>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.onSurface
    val minP = points.minOf { it.second }
    val maxP = points.maxOf { it.second }
    val t0 = points.first().first
    val t1 = points.last().first
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val span = (maxP - minP).coerceAtLeast(1).toFloat()
        val tspan = (t1 - t0).coerceAtLeast(1).toFloat()
        val path = Path()
        val pts = points.map { (t, pr) -> Offset((t - t0) / tspan * w, h - (pr - minP) / span * h * 0.8f - h * 0.1f) }
        pts.forEachIndexed { i, o -> if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
        drawPath(path, lineColor, style = Stroke(width = 4f))
        pts.forEach { drawCircle(Yellow, 7f, it) }
    }
}
