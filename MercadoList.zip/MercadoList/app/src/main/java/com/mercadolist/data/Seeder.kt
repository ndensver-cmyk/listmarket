package com.mercadolist.data

import android.content.Context
import androidx.room.withTransaction
import com.mercadolist.core.StoreSource
import com.mercadolist.core.normalize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CatalogSeeder(private val db: AppDb, private val context: Context) {

    suspend fun seedIfNeeded() = withContext(Dispatchers.IO) {
        if (db.catalog().variantCount() > 0) return@withContext
        val lines = context.assets.open("catalog_seed.txt").bufferedReader().use { it.readLines() }
        val refs = CatalogGenerator.generate(lines)

        db.withTransaction {
            val cd = db.catalog()
            val cats = CatalogGenerator.categories.mapIndexed { i, n -> CategoryEntity(name = n, code = CatalogGenerator.codes[i]) }
            val catIds = cd.insertCategories(cats)
            val catByName = cats.indices.associate { cats[it].name to catIds[it] }
            val codeByName = cats.associate { it.name to it.code }

            val brandRefs = refs.distinctBy { it.brand }
            val brandIds = cd.insertBrands(brandRefs.map { BrandEntity(name = it.brand, isStoreBrand = it.isStoreBrand) })
            val brandByName = brandRefs.indices.associate { brandRefs[it].brand to brandIds[it] }

            val productKeys = LinkedHashMap<String, SeedRef>()
            for (r in refs) productKeys.putIfAbsent("${r.category}|${r.subcategory}|${r.product}|${r.brand}", r)
            val keyList = productKeys.keys.toList()
            val productIds = cd.insertProducts(productKeys.values.map {
                ProductEntity(
                    name = it.product, brandId = brandByName.getValue(it.brand), categoryId = catByName.getValue(it.category),
                    subcategory = it.subcategory
                )
            })
            val productIdByKey = keyList.indices.associate { keyList[it] to productIds[it] }

            val counters = HashMap<String, Int>()
            cd.insertVariants(refs.map { r ->
                val code = codeByName.getValue(r.category)
                val n = (counters[code] ?: 0) + 1
                counters[code] = n
                VariantEntity(
                    productId = productIdByKey.getValue("${r.category}|${r.subcategory}|${r.product}|${r.brand}"),
                    sku = "$code-" + n.toString().padStart(5, '0'),
                    label = r.variant,
                    presentation = r.presentation,
                    amount = r.amount,
                    unit = r.unit,
                    search = normalize("${r.product} ${r.brand} ${r.variant} ${r.presentation}")
                )
            })

            db.price().insertStores(CatalogGenerator.storeNames.map { StoreEntity(name = it, sourceStatus = StoreSource.PENDIENTE.name) })
            db.price().insertSources(listOf(
                PriceSourceEntity(name = "Comprobado en fuente", evidence = "Precio verificado contra la tienda"),
                PriceSourceEntity(name = "Registrado por el usuario", evidence = "Ingresado manualmente"),
                PriceSourceEntity(name = "Importado (CSV)", evidence = "Archivo importado por el usuario")
            ))
        }
    }
}
