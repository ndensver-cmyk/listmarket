@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.mercadolist.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mercadolist.core.*
import com.mercadolist.exploreRoute
import com.mercadolist.goTab

private data class Quick(val title: String, val icon: ImageVector, val route: String, val tab: Boolean = false)

@Composable
fun HomeScreen(vm: AppVM, nav: NavController) {
    val cats by vm.categories.collectAsState()
    val promos by vm.promotions.collectAsState()
    val st by vm.settings.collectAsState()
    val active by vm.activeList.collectAsState()
    val sums by vm.summaries.collectAsState()
    val lists by vm.lists.collectAsState()
    val ready by vm.ready.collectAsState()
    val count by vm.catalogCount.collectAsState()
    var cityDialog by remember { mutableStateOf(false) }
    var addTo by remember { mutableStateOf<Long?>(null) }
    val snack = remember { SnackbarHostState() }

    val quick = listOf(
        Quick("Mis listas", Icons.AutoMirrored.Filled.List, "lists", true),
        Quick("Supermercados", Icons.Filled.Store, "stores"),
        Quick("Presupuesto", Icons.Filled.Savings, "budget"),
        Quick("Historial", Icons.Filled.History, "history"),
        Quick("Mi despensa", Icons.Filled.Inventory2, "inventory"),
        Quick("Favoritos", Icons.Filled.Favorite, "favorites"),
        Quick("Escáner", Icons.Filled.QrCodeScanner, "scanner")
    )

    Scaffold(containerColor = MaterialTheme.colorScheme.background, snackbarHost = { SnackbarHost(snack) }) { _ ->
        LazyColumn(Modifier.fillMaxSize()) {
            // Cabecera amarilla
            item {
                Column(Modifier.fillMaxWidth().background(Yellow).statusBarsPadding().padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("MercadoList", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        IconButton(onClick = { nav.goTab("profile") }) { Icon(Icons.Filled.Notifications, "Recordatorios", tint = Ink) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color.White)
                            .clickable { nav.navigate(exploreRoute()) }.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Search, null, tint = Ink)
                        Spacer(Modifier.width(10.dp))
                        Text("Buscar arroz, leche, huevos…", color = Color(0xFF6B6B63))
                    }
                }
            }
            // Franja negra: ciudad
            item {
                Row(
                    Modifier.fillMaxWidth().background(Ink).clickable { cityDialog = true }.padding(horizontal = 16.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.LocationOn, null, tint = Yellow, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Comprando en ${st.city}", color = Color.White, modifier = Modifier.weight(1f))
                    Icon(Icons.Filled.Edit, "Cambiar ciudad", tint = Yellow, modifier = Modifier.size(16.dp))
                }
            }
            if (!ready) item {
                Column(Modifier.padding(16.dp)) {
                    Text("Preparando el catálogo por primera vez…", fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
            // Accesos rápidos
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    items(quick) { q ->
                        Column(Modifier.clickable { if (q.tab) nav.goTab(q.route) else nav.navigate(q.route) }, horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(58.dp).clip(CircleShape).background(Yellow), contentAlignment = Alignment.Center) {
                                Icon(q.icon, q.title, tint = Ink, modifier = Modifier.size(28.dp))
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(q.title, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
            // Resumen
            item {
                InfoCard(Modifier.padding(horizontal = 16.dp)) {
                    Text("Resumen", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) { Text("$count", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp); Text("referencias", fontSize = 12.sp) }
                        Column(Modifier.weight(1f)) { Text("${lists.size}", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp); Text("listas abiertas", fontSize = 12.sp) }
                        Column(Modifier.weight(1f)) {
                            Text(active?.let { Fmt.cop(sums[it.id]?.total ?: 0.0) } ?: "—", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                            Text(if (active != null) "en el carrito" else "sin carrito", fontSize = 12.sp)
                        }
                    }
                }
            }
            // Categorías
            item { SectionTitle("Categorías") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(cats, key = { it.id }) { c ->
                        Column(
                            Modifier.width(92.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
                                .clickable { nav.navigate(exploreRoute(cat = c.id)) }.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(Modifier.size(44.dp).clip(CircleShape).background(catColor(c.id)), contentAlignment = Alignment.Center) {
                                Icon(catIcon(c.name), null, tint = Ink)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(c.name, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 13.sp)
                        }
                    }
                }
            }
            // Promociones registradas
            item { SectionTitle("Promociones registradas") }
            if (promos.isEmpty()) item {
                InfoCard(Modifier.padding(horizontal = 16.dp)) {
                    Text("Aún no hay promociones.", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Cuando registres un precio con su valor anterior (o importes un CSV), los descuentos aparecerán aquí. MercadoList no inventa precios ni ofertas.",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(promos, key = { it.price.priceId }) { pr ->
                        Card(
                            onClick = { nav.navigate("product/${pr.variant.variantId}") }, modifier = Modifier.width(170.dp),
                            shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Box {
                                    ProductImage(pr.variant.imageUrl, pr.variant.brand, pr.variant.categoryId, Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(12.dp)))
                                    pr.price.discountPct?.let { Box(Modifier.padding(6.dp)) { DiscountTag(it) } }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(pr.variant.fullName, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("${pr.variant.presentation} · ${pr.price.storeName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                pr.price.originalPrice?.let { Text(Fmt.cop(it), fontSize = 12.sp, textDecoration = TextDecoration.LineThrough, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(Fmt.cop(pr.price.price), color = AlertRed, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                                    FilledIconButton(
                                        onClick = { addTo = pr.variant.variantId }, modifier = Modifier.size(34.dp),
                                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Yellow, contentColor = Ink)
                                    ) { Icon(Icons.Filled.Add, "Agregar") }
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (cityDialog) TextInputDialog("¿Dónde compras?", "Ciudad", st.city, onSave = { vm.setCity(it) }, onDismiss = { cityDialog = false })
    addTo?.let { id -> AddToListDialog(vm, id, onDismiss = { addTo = null }, onAdded = { }) }
}
