package com.mercadolist.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Yellow = Color(0xFFFFE600)
val Ink = Color(0xFF141414)
val AlertRed = Color(0xFFE53935)
val OkGreen = Color(0xFF2E7D32)
val WarnOrange = Color(0xFFEF6C00)

private val LightScheme = lightColorScheme(
    primary = Ink, onPrimary = Yellow,
    primaryContainer = Yellow, onPrimaryContainer = Ink,
    secondary = Yellow, onSecondary = Ink,
    secondaryContainer = Color(0xFFFFF4A3), onSecondaryContainer = Ink,
    background = Color(0xFFF6F6F3), onBackground = Ink,
    surface = Color.White, onSurface = Ink,
    surfaceVariant = Color(0xFFEFEFE9), onSurfaceVariant = Color(0xFF55554F),
    outline = Color(0xFFD6D6CE), error = AlertRed
)

private val DarkScheme = darkColorScheme(
    primary = Yellow, onPrimary = Ink,
    primaryContainer = Color(0xFF3A3500), onPrimaryContainer = Yellow,
    secondary = Yellow, onSecondary = Ink,
    secondaryContainer = Color(0xFF2E2B00), onSecondaryContainer = Yellow,
    background = Color(0xFF0F0F0F), onBackground = Color(0xFFF2F2EC),
    surface = Color(0xFF1B1B1B), onSurface = Color(0xFFF2F2EC),
    surfaceVariant = Color(0xFF262622), onSurfaceVariant = Color(0xFFC9C9C0),
    outline = Color(0xFF3F3F39), error = Color(0xFFFF6B63)
)

@Composable
fun MercadoTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}
