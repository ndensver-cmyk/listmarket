@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.mercadolist.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mercadolist.core.Fmt
import kotlinx.coroutines.launch

@Composable
fun ExploreScreen(vm: AppVM, nav: NavController, listId: Long, ean: String, initialCat: Long, initialQuery: String) {
    var query by rememberSaveable { mutableStateOf(initialQuery) }
    var cat by rememberSaveable { mutableLongStateOf(initialCat) }
    var sortByUnit by rememberSaveable { mutableStateOf(false) }
    val cats by vm.categories.collectAsState()
    val rows by remember(query, cat) { vm.search(query, cat) }.collectAsState(emptyList())
    val shown = if (sortByUnit) rows.sortedWith(compareBy({ it.view.unit }, { it.best?.let { p -> Fmt.unitValue(p.price, it.view.amount) } ?: Double.MAX_VALUE })) else rows
    var addTo by remember { mutableStateOf<Long?>(null) }
    var custom by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Screen(
        title = if (listId > 0) "Agregar a la lista" else "Explorar",
        onBack = if (listId > 0 || ean.isNotBlank()) ({ nav.popBackStack() }) else null,
        snackbar = snack,
        actions = {
            IconButton(onClick = { nav.navigate("scanner") }) { Icon(Icons.Filled.QrCodeScanner, "Escanear") }
            IconButton(onClick = { custom = true }) { Icon(Icons.Filled.AddCircle, "Producto personalizado") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (ean.isNotBlank()) {
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Text("Código $ean sin registrar. Toca el producto al que pertenece para vincularlo.", Modifier.padding(12.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Buscar producto, marca o presentación") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Borrar") } }
            )
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected = cat == 0L, onClick = { cat = 0L }, label = { Text("Todas") }) }
                items(cats, key = { it.id }) { c -> FilterChip(selected = cat == c.id, onClick = { cat = c.id }, label = { Text(c.name) }) }
            }
            Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${shown.size} resultados${if (shown.size >= 300) " (máx. 300, afina la búsqueda)" else ""}", fontSize = 12.sp, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                FilterChip(selected = sortByUnit, onClick = { sortByUnit = !sortByUnit }, label = { Text("Precio por kg / L / un") })
            }
            if (shown.isEmpty()) {
                EmptyState(Icons.Filled.Search, "Sin resultados", "Prueba con otra palabra o crea un producto personalizado con el botón +.")
            } else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(shown, key = { it.view.variantId }) { r ->
                    VariantRowCard(
                        r,
                        onClick = {
                            if (ean.isNotBlank()) vm.linkEan(ean, r.view.variantId)
                            nav.navigate("product/${r.view.variantId}")
                        },
                        onAdd = {
                            if (listId > 0) {
                                vm.addVariant(listId, r.view.variantId)
                                scope.launch { snack.showSnackbar("Agregado: ${r.view.fullName}") }
                            } else addTo = r.view.variantId
                        }
                    )
                }
            }
        }
    }

    addTo?.let { id -> AddToListDialog(vm, id, onDismiss = { addTo = null }, onAdded = { n -> scope.launch { snack.showSnackbar("Agregado a $n") } }) }
    if (custom) CustomProductDialog(vm, onDismiss = { custom = false }, onCreated = { id -> nav.navigate("product/$id") })
}
