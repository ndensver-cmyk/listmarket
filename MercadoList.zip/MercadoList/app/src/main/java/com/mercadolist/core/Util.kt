package com.mercadolist.core

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Un precio con más de 30 días nunca se trata como vigente. */
const val STALE_MS = 30L * 24 * 60 * 60 * 1000

enum class PriceStatus(val label: String) {
    COMPROBADO("Precio comprobado"),
    REGISTRADO("Registrado por el usuario"),
    REVISION("Necesita revisión"),
    SIN_INFO("No hay información disponible")
}

enum class StoreSource(val label: String) {
    VERIFICADO("Verificado"),
    MANUAL("Actualizado manualmente"),
    IMPORTADO("Importado"),
    PENDIENTE("Pendiente")
}

object Fmt {
    private val sym = DecimalFormatSymbols(Locale("es", "CO")).apply {
        groupingSeparator = '.'
        decimalSeparator = ','
    }
    private val money = DecimalFormat("#,##0", sym)
    private val number = DecimalFormat("#,##0.##", sym)

    fun cop(v: Long?): String = if (v == null) "—" else "$" + money.format(v)
    fun cop(v: Double): String = "$" + money.format(Math.round(v))
    fun qty(v: Double): String = number.format(v)

    fun content(amount: Double, unit: String): String = when (unit) {
        "g" -> if (amount >= 1000) "${qty(amount / 1000)} kg" else "${qty(amount)} g"
        "ml" -> if (amount >= 1000) "${qty(amount / 1000)} L" else "${qty(amount)} ml"
        else -> "${qty(amount)} un"
    }

    /** Precio por kg, litro o unidad. */
    fun unitPrice(price: Long, amount: Double, unit: String): String? {
        if (amount <= 0) return null
        return when (unit) {
            "g" -> cop(price / amount * 1000) + " / kg"
            "ml" -> cop(price / amount * 1000) + " / L"
            "un" -> cop(price / amount) + " / un"
            else -> null
        }
    }

    fun unitValue(price: Long, amount: Double): Double = if (amount <= 0) Double.MAX_VALUE else price / amount

    fun date(ms: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale("es", "CO")).format(Date(ms))
}

fun normalize(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase(Locale("es"))

fun String.toMoney(): Long? = filter { it.isDigit() }.toLongOrNull()
fun String.toQty(): Double? = replace(',', '.').toDoubleOrNull()

/** Rango [inicio, fin] del periodo; offset 0 = actual, -1 = anterior. */
fun periodRange(period: String, offset: Int = 0): Pair<Long, Long> {
    val c = Calendar.getInstance().apply {
        firstDayOfWeek = Calendar.MONDAY
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    return when (period) {
        "SEMANAL" -> {
            c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            c.add(Calendar.WEEK_OF_YEAR, offset)
            val s = c.timeInMillis
            c.add(Calendar.WEEK_OF_YEAR, 1)
            s to c.timeInMillis - 1
        }
        "QUINCENAL" -> {
            var idx = c.get(Calendar.YEAR) * 24 + c.get(Calendar.MONTH) * 2 + (if (c.get(Calendar.DAY_OF_MONTH) > 15) 1 else 0)
            idx += offset
            val year = idx / 24
            val month = (idx % 24) / 2
            val second = (idx % 2) == 1
            val s = Calendar.getInstance().apply {
                set(year, month, if (second) 16 else 1, 0, 0, 0); set(Calendar.MILLISECOND, 0)
            }
            val e = (s.clone() as Calendar).apply {
                if (second) { set(Calendar.DAY_OF_MONTH, 1); add(Calendar.MONTH, 1) } else set(Calendar.DAY_OF_MONTH, 16)
            }
            s.timeInMillis to e.timeInMillis - 1
        }
        else -> {
            c.set(Calendar.DAY_OF_MONTH, 1)
            c.add(Calendar.MONTH, offset)
            val s = c.timeInMillis
            c.add(Calendar.MONTH, 1)
            s to c.timeInMillis - 1
        }
    }
}

fun periodLabel(range: Pair<Long, Long>): String = "${Fmt.date(range.first)} – ${Fmt.date(range.second)}"
fun periodName(p: String) = when (p) { "SEMANAL" -> "Semanal"; "QUINCENAL" -> "Quincenal"; else -> "Mensual" }
