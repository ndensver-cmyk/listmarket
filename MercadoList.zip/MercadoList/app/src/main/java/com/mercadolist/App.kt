package com.mercadolist

import android.app.Application
import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.mercadolist.data.AppDb
import com.mercadolist.data.SettingsStore
import com.mercadolist.work.createChannels
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@HiltAndroidApp
class MercadoListApp : Application() {
    override fun onCreate() {
        super.onCreate()
        createChannels(this)
    }
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE products ADD COLUMN photoTried INTEGER NOT NULL DEFAULT 0")
    }
}

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun db(@ApplicationContext c: Context): AppDb = Room.databaseBuilder(c, AppDb::class.java, "mercadolist.db").addMigrations(MIGRATION_1_2).build()

    @Provides @Singleton
    fun settings(@ApplicationContext c: Context): SettingsStore = SettingsStore(c)
}
