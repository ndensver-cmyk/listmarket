package com.mercadolist

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.mercadolist.data.AppDb
import com.mercadolist.data.SettingsStore
import com.mercadolist.work.createChannels
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@HiltAndroidApp
class MercadoListApp : Application() {
    override fun onCreate() {
        super.onCreate()
        createChannels(this)
    }
}

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun db(@ApplicationContext c: Context): AppDb = Room.databaseBuilder(c, AppDb::class.java, "mercadolist.db").build()

    @Provides @Singleton
    fun settings(@ApplicationContext c: Context): SettingsStore = SettingsStore(c)
}
