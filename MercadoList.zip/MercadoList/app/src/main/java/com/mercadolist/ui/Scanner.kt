package com.mercadolist.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavController
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.mercadolist.exploreRoute
import java.util.concurrent.atomic.AtomicBoolean

@Composable
fun ScannerScreen(vm: AppVM, nav: NavController) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }
    val handled = remember { AtomicBoolean(false) }

    Screen(title = "Escanear código", onBack = { nav.popBackStack() }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (granted) {
                CameraPreview(owner) { code ->
                    if (handled.compareAndSet(false, true)) {
                        vm.lookupEan(code) { id ->
                            nav.popBackStack()
                            if (id != null) nav.navigate("product/$id") else nav.navigate(exploreRoute(ean = code))
                        }
                    }
                }
                Text("Apunta al código de barras del producto", Modifier.align(Alignment.BottomCenter).padding(24.dp))
            } else {
                Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }, modifier = Modifier.align(Alignment.Center)) { Text("Permitir cámara") }
            }
        }
    }
}

@Composable
private fun CameraPreview(owner: LifecycleOwner, onCode: (String) -> Unit) {
    AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
        val pv = PreviewView(c)
        val future = ProcessCameraProvider.getInstance(c)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
            val scanner = BarcodeScanning.getClient(
                BarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E)
                    .build()
            )
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(ContextCompat.getMainExecutor(c)) { proxy -> analyze(proxy, scanner, onCode) }
            provider.unbindAll()
            provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(c))
        pv
    })
}

@androidx.annotation.OptIn(ExperimentalGetImage::class)
private fun analyze(proxy: ImageProxy, scanner: BarcodeScanner, onCode: (String) -> Unit) {
    val img = proxy.image
    if (img == null) { proxy.close(); return }
    val input = InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees)
    scanner.process(input)
        .addOnSuccessListener { codes -> codes.firstOrNull()?.rawValue?.let(onCode) }
        .addOnCompleteListener { proxy.close() }
}
