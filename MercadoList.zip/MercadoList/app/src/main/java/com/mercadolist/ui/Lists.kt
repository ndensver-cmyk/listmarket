@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.mercadolist.ui

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import com.mercadolist.core.*
import com.mercadolist.data.*
import com.mercadolist.exploreRoute
import com.mercadolist.goTab
import kotlinx.coroutines.launch

private val suggestedNames = listOf(
    "Mercado semanal", "Mercado mensual", "Compras de la casa", "Mercado de diciembre",
    "Compra para una fiesta", "Productos pendientes", "Compras personales"
)

// ============================ LISTAS ============================

@Composable
fun ListsScreen(vm: AppVM, nav: NavController) {
    val lists by vm.lists.collectAsState()
    val templates by vm.templates.collectAsState()
    val sums by vm.summaries.collectAsState()
    var newDialog by remember { mutableStateOf(false) }
    var deleteId by remember { mutableStateOf<Long?>(null) }

    Screen(
        title = "Mis listas",
        actions = { IconButton(onClick = { nav.navigate("history") }) { Icon(Icons.Filled.History, "Mercados anteriores") } },
        fab = {
            ExtendedFloatingActionButton(onClick = { newDialog = true }, containerColor = Yellow, contentColor = Ink) {
                Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Nueva lista")
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (lists.isEmpty()) item {
                EmptyState(Icons.AutoMirrored.Filled.List, "Aún no tienes listas", "Crea tu primer mercado: semanal, mensual, de diciembre o para una fiesta.")
            }
            items(lists, key = { it.id }) { l ->
                var menu by remember { mutableStateOf(false) }
                val s = sums[l.id]
                Card(onClick = { nav.navigate("list/${l.id}") }, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(l.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
                                if (l.isActive) Text("En carrito", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.then(Modifier).padding(0.dp), color = OkGreen)
                            }
                            Text("${s?.itemCount ?: 0} productos · ${Fmt.cop(s?.total ?: 0.0)}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Actualizada ${Fmt.date(l.updatedAt)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Opciones") }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem(text = { Text("Usar como carrito") }, leadingIcon = { Icon(Icons.Filled.ShoppingCart, null) }, onClick = { vm.setActive(l.id); menu = false })
                                DropdownMenuItem(text = { Text("Duplicar") }, leadingIcon = { Icon(Icons.Filled.ContentCopy, null) }, onClick = { vm.copyList(l.id, false, "${l.name} (copia)"); menu = false })
                                DropdownMenuItem(text = { Text("Guardar como plantilla") }, leadingIcon = { Icon(Icons.Filled.Bookmark, null) }, onClick = { vm.copyList(l.id, true, l.name); menu = false })
                                DropdownMenuItem(text = { Text("Eliminar") }, leadingIcon = { Icon(Icons.Filled.Delete, null) }, onClick = { deleteId = l.id; menu = false })
                            }
                        }
                    }
                }
            }
            if (templates.isNotEmpty()) {
                item { SectionTitle("Plantillas", Modifier.padding(start = 0.dp)) }
                items(templates, key = { "t${it.id}" }) { t ->
                    val s = sums[t.id]
                    InfoCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t.name, fontWeight = FontWeight.Bold)
                                Text("${s?.itemCount ?: 0} productos", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { vm.copyList(t.id, false, t.name) { id -> nav.navigate("list/$id") } }) { Text("Usar") }
                            IconButton(onClick = { deleteId = t.id }) { Icon(Icons.Filled.Delete, "Eliminar plantilla") }
                        }
                    }
                }
            }
        }
    }

    if (newDialog) NewListDialog(onDismiss = { newDialog = false }) { name -> vm.createList(name) { id -> nav.navigate("list/$id") } }
    deleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteId = null }, title = { Text("¿Eliminar?") }, text = { Text("Se borrarán la lista y sus productos.") },
            confirmButton = { TextButton(onClick = { vm.deleteList(id); deleteId = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { deleteId = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun NewListDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Nueva lista") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    suggestedNames.forEach { s -> AssistChip(onClick = { name = s }, label = { Text(s, fontSize = 12.sp) }) }
                }
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onCreate(name.trim()); onDismiss() }) { Text("Crear") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ============================ DETALLE ============================

@Composable
fun ListDetailScreen(vm: AppVM, nav: NavController, listId: Long) {
    val list by remember(listId) { vm.list(listId) }.collectAsState(null)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Screen(
        title = list?.name ?: "Lista", onBack = { nav.popBackStack() },
        actions = {
            IconButton(onClick = {
                scope.launch {
                    val text = vm.shareText(listId)
                    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                    ctx.startActivity(Intent.createChooser(i, "Compartir lista"))
                }
            }) { Icon(Icons.Filled.Share, "Compartir") }
            IconButton(onClick = {
                scope.launch {
                    val f = vm.exportPdf(listId)
                    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                    val i = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    ctx.startActivity(Intent.createChooser(i, "Exportar PDF"))
                }
            }) { Icon(Icons.Filled.PictureAsPdf, "Exportar PDF") }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Más") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Renombrar") }, onClick = { rename = true; menu = false })
                    DropdownMenuItem(text = { Text("Usar como carrito") }, onClick = { vm.setActive(listId); menu = false })
                    DropdownMenuItem(text = { Text("Duplicar") }, onClick = { vm.copyList(listId, false, "${list?.name} (copia)") { nav.navigate("list/$it") }; menu = false })
                    DropdownMenuItem(text = { Text("Guardar como plantilla") }, onClick = { vm.copyList(listId, true, list?.name ?: "Plantilla"); menu = false })
                    DropdownMenuItem(text = { Text("Eliminar") }, onClick = { confirmDelete = true; menu = false })
                }
            }
        }
    ) { pad ->
        ListBody(vm, nav, listId, cartMode = false, pad = pad, onFinish = {})
    }

    if (rename) TextInputDialog("Renombrar lista", "Nombre", list?.name ?: "", onSave = { vm.renameList(listId, it) }, onDismiss = { rename = false })
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false }, title = { Text("¿Eliminar lista?") },
        confirmButton = { TextButton(onClick = { vm.deleteList(listId); confirmDelete = false; nav.popBackStack() }) { Text("Eliminar") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
    )
}

// ============================ CARRITO ============================

@Composable
fun CartScreen(vm: AppVM, nav: NavController) {
    val active by vm.activeList.collectAsState()
    val stores by vm.stores.collectAsState()
    var finish by remember { mutableStateOf(false) }
    val a = active

    Screen(title = "Carrito") { pad ->
        if (a == null) {
            EmptyState(
                Icons.Filled.ShoppingCart, "Tu carrito está vacío", "Elige una de tus listas como carrito para ir marcando lo que compras y ver los totales.",
                Modifier.padding(pad), action = { Button(onClick = { nav.goTab("lists") }, colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Ink)) { Text("Ver mis listas") } }
            )
        } else {
            Column(Modifier.padding(pad).fillMaxSize()) {
                Text(a.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 0.dp))
                Box(Modifier.weight(1f)) { ListBody(vm, nav, a.id, cartMode = true, pad = PaddingValues(0.dp), onFinish = { finish = true }) }
            }
        }
    }

    if (finish && a != null) {
        var store by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { finish = false }, title = { Text("Finalizar compra") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Se guardará en tu historial con lo marcado como comprado (o toda la lista si no marcaste nada).", fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("¿Dónde compraste?", fontWeight = FontWeight.SemiBold)
                    stores.forEach { s ->
                        Row(Modifier.fillMaxWidth().clickable { store = s.name }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = store == s.name, onClick = { store = s.name }); Text(s.name)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.finishPurchase(a.id, store) { nav.navigate("history") }; finish = false }) { Text("Finalizar") } },
            dismissButton = { TextButton(onClick = { finish = false }) { Text("Cancelar") } }
        )
    }
}

// ============================ CUERPO COMPARTIDO ============================

@Composable
fun ListBody(vm: AppVM, nav: NavController, listId: Long, cartMode: Boolean, pad: PaddingValues, onFinish: () -> Unit) {
    val list by remember(listId) { vm.list(listId) }.collectAsState(null)
    val listItems by remember(listId) { vm.items(listId) }.collectAsState(emptyList())
    val inventory by vm.inventory.collectAsState()
    val stock = remember(inventory) { inventory.filter { it.productId != null }.associateBy { it.productId!! } }
    var edit by remember { mutableStateOf<ItemView?>(null) }
    var manual by remember { mutableStateOf(false) }
    var budgetDialog by remember { mutableStateOf(false) }

    val total = listItems.sumOf { (it.unitPrice ?: 0L) * it.quantity }
    val bought = listItems.filter { it.purchased }.sumOf { (it.unitPrice ?: 0L) * it.quantity }
    val pending = total - bought
    val noPrice = listItems.count { it.unitPrice == null }
    val budget = list?.budget

    LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            InfoCard {
                Row {
                    Column(Modifier.weight(1f)) { Text("Total estimado", fontSize = 12.sp); Text(Fmt.cop(total), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp) }
                    Column(Modifier.weight(1f)) { Text("Comprado", fontSize = 12.sp); Text(Fmt.cop(bought), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = OkGreen) }
                    Column(Modifier.weight(1f)) { Text("Pendiente", fontSize = 12.sp); Text(Fmt.cop(pending), fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Presupuesto", Modifier.weight(1f), fontSize = 13.sp)
                    Text(budget?.let { Fmt.cop(it) } ?: "Sin definir", fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = { budgetDialog = true }, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.Edit, "Editar presupuesto", Modifier.size(18.dp)) }
                }
                if (budget != null) {
                    val left = budget - total
                    Row { Text("Dinero restante estimado", Modifier.weight(1f), fontSize = 13.sp); Text(Fmt.cop(left.toDouble()), fontWeight = FontWeight.Bold, color = if (left < 0) AlertRed else OkGreen) }
                    if (left < 0) Text("⚠ La lista supera tu presupuesto por ${Fmt.cop(-left.toDouble())}.", color = AlertRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                if (noPrice > 0) Text("$noPrice productos sin precio: el total puede ser mayor. Toca un producto para ponerle precio.", fontSize = 12.sp, color = WarnOrange)
            }
        }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!cartMode) {
                    Button(onClick = { nav.navigate(exploreRoute(listId = listId)) }, colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Ink)) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(4.dp)); Text("Productos") }
                    OutlinedButton(onClick = { manual = true }) { Text("Producto manual") }
                    OutlinedButton(onClick = { nav.navigate("compare/$listId") }) { Icon(Icons.Filled.SwapHoriz, null); Spacer(Modifier.width(4.dp)); Text("Comparar") }
                } else {
                    Button(onClick = onFinish, colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Yellow)) { Icon(Icons.Filled.CheckCircle, null); Spacer(Modifier.width(4.dp)); Text("Finalizar compra") }
                    OutlinedButton(onClick = { nav.navigate("list/$listId") }) { Text("Abrir lista") }
                    OutlinedButton(onClick = { nav.navigate("compare/$listId") }) { Text("Comparar") }
                }
            }
        }
        if (listItems.isEmpty()) item { EmptyState(Icons.Filled.AddShoppingCart, "Lista vacía", "Agrega productos del catálogo o escribe uno manual.") }
        items(listItems, key = { it.id }) { it ->
            Card(onClick = { edit = it }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(8.dp, 8.dp, 4.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = it.purchased, onCheckedChange = { c -> vm.togglePurchased(it.id, c) })
                    Column(Modifier.weight(1f)) {
                        Text(it.name, fontWeight = FontWeight.SemiBold, textDecoration = if (it.purchased) TextDecoration.LineThrough else null, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        val sub = listOfNotNull(it.brand, it.presentation, it.amount?.let { a -> Fmt.content(a, it.unit ?: "un") }).joinToString(" · ")
                        if (sub.isNotBlank()) Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        it.productId?.let { pid -> stock[pid] }?.let { s ->
                            Text("En casa: ${Fmt.qty(s.quantity)} ${s.unit}" + if (s.quantity > 0) " (quizá no necesitas comprar)" else " (se acabó)", fontSize = 11.sp, color = if (s.quantity > 0) OkGreen else WarnOrange)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            QtyStepper(it.quantity) { q -> vm.updateItem(it.id, q, it.unitPrice) }
                            Text(
                                if (it.unitPrice == null) "× sin precio" else "× ${Fmt.cop(it.unitPrice)}", fontSize = 13.sp,
                                color = if (it.unitPrice == null) WarnOrange else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(Fmt.cop((it.unitPrice ?: 0L) * it.quantity), fontWeight = FontWeight.ExtraBold)
                        IconButton(onClick = { vm.deleteItem(it.id) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.Delete, "Quitar", Modifier.size(18.dp)) }
                    }
                }
            }
        }
    }

    edit?.let { ItemEditDialog(vm, it, onDismiss = { edit = null }) }
    if (manual) ManualItemDialog(vm, listId, onDismiss = { manual = false })
    if (budgetDialog) EditAmountDialog("Presupuesto de la lista", budget, onSave = { vm.setListBudget(listId, it) }, onDismiss = { budgetDialog = false })
}

@Composable
private fun ItemEditDialog(vm: AppVM, item: ItemView, onDismiss: () -> Unit) {
    var qty by remember { mutableStateOf(Fmt.qty(item.quantity).replace(".", "").replace(',', '.')) }
    var price by remember { mutableStateOf(item.unitPrice?.toString() ?: "") }
    var options by remember { mutableStateOf<List<VariantView>>(emptyList()) }
    var chosen by remember { mutableStateOf(item.variantId) }
    LaunchedEffect(item.id) { item.productId?.let { options = vm.variantsOfProduct(it) } }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField(qty, { qty = it }, "Cantidad", Modifier.fillMaxWidth(), decimal = true)
                NumberField(price, { price = it }, "Precio unitario (COP)", Modifier.fillMaxWidth())
                if (options.size > 1) {
                    Text("Presentación", fontWeight = FontWeight.SemiBold)
                    options.forEach { o ->
                        Row(Modifier.fillMaxWidth().clickable { chosen = o.variantId }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = chosen == o.variantId, onClick = { chosen = o.variantId })
                            Text("${o.label.ifBlank { o.presentation }} · ${Fmt.content(o.amount, o.unit)}", fontSize = 13.sp)
                        }
                    }
                    Text("Al cambiar la presentación el precio se actualiza al vigente (si existe).", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val newV = chosen
                val q = qty.toQty()?.takeIf { it > 0 } ?: item.quantity
                if (newV != null && newV != item.variantId) vm.changeVariant(item.id, newV, q)
                else vm.updateItem(item.id, q, price.toMoney())
                onDismiss()
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun ManualItemDialog(vm: AppVM, listId: Long, onDismiss: () -> Unit) {
    val cats by vm.categories.collectAsState()
    var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var price by remember { mutableStateOf("") }
    var cat by remember { mutableLongStateOf(0L) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Producto manual") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                NumberField(qty, { qty = it }, "Cantidad", Modifier.fillMaxWidth(), decimal = true)
                NumberField(price, { price = it }, "Precio unitario (opcional)", Modifier.fillMaxWidth())
                Text("Categoría (opcional)", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    cats.forEach { c -> FilterChip(selected = cat == c.id, onClick = { cat = if (cat == c.id) 0L else c.id }, label = { Text(c.name, fontSize = 11.sp) }) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { vm.addManual(listId, name.trim(), qty.toQty() ?: 1.0, price.toMoney(), cat); onDismiss() }) { Text("Agregar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
