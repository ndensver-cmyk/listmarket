@file:OptIn(ExperimentalMaterial3Api::class)

package com.mercadolist

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mercadolist.ui.*
import dagger.hilt.android.AndroidEntryPoint

fun exploreRoute(listId: Long = 0, ean: String = "", cat: Long = 0, q: String = "") =
    "explore?listId=$listId&ean=$ean&cat=$cat&q=${Uri.encode(q)}"

fun NavController.goTab(route: String) {
    navigate(route) {
        popUpTo(graph.startDestinationId) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AppVM = hiltViewModel()
            val st by vm.settings.collectAsState()
            val dark = when (st.dark) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            MercadoTheme(dark) { AppRoot(vm) }
        }
    }
}

private data class NavTab(val route: String, val label: String, val icon: ImageVector)

@Composable
private fun AppRoot(vm: AppVM) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        NavTab("home", "Inicio", Icons.Filled.Home),
        NavTab("explore", "Explorar", Icons.Filled.Search),
        NavTab("lists", "Listas", Icons.AutoMirrored.Filled.List),
        NavTab("cart", "Carrito", Icons.Filled.ShoppingCart),
        NavTab("profile", "Perfil", Icons.Filled.Person)
    )
    val current = tabs.firstOrNull { route?.startsWith(it.route) == true }

    Scaffold(
        bottomBar = {
            if (current != null) {
                NavigationBar(containerColor = Ink) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = t == current,
                            onClick = { nav.goTab(t.route) },
                            icon = { Icon(t.icon, t.label) },
                            label = { Text(t.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Ink, selectedTextColor = Yellow, indicatorColor = Yellow,
                                unselectedIconColor = Color(0xFFB8B8B0), unselectedTextColor = Color(0xFFB8B8B0)
                            )
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(bottom = if (current != null) pad.calculateBottomPadding() else 0.dp)) {
            composable("home") { HomeScreen(vm, nav) }
            composable(
                "explore?listId={listId}&ean={ean}&cat={cat}&q={q}",
                arguments = listOf(
                    navArgument("listId") { type = NavType.LongType; defaultValue = 0L },
                    navArgument("ean") { type = NavType.StringType; defaultValue = "" },
                    navArgument("cat") { type = NavType.LongType; defaultValue = 0L },
                    navArgument("q") { type = NavType.StringType; defaultValue = "" }
                )
            ) { e ->
                ExploreScreen(
                    vm, nav,
                    listId = e.arguments?.getLong("listId") ?: 0L,
                    ean = e.arguments?.getString("ean") ?: "",
                    initialCat = e.arguments?.getLong("cat") ?: 0L,
                    initialQuery = e.arguments?.getString("q") ?: ""
                )
            }
            composable("lists") { ListsScreen(vm, nav) }
            composable("cart") { CartScreen(vm, nav) }
            composable("profile") { ProfileScreen(vm, nav) }
            composable("product/{id}", listOf(navArgument("id") { type = NavType.LongType })) { e ->
                ProductScreen(vm, nav, e.arguments?.getLong("id") ?: 0L)
            }
            composable("list/{id}", listOf(navArgument("id") { type = NavType.LongType })) { e ->
                ListDetailScreen(vm, nav, e.arguments?.getLong("id") ?: 0L)
            }
            composable("compare/{id}", listOf(navArgument("id") { type = NavType.LongType })) { e ->
                CompareScreen(vm, nav, e.arguments?.getLong("id") ?: 0L)
            }
            composable("stores") { StoresScreen(vm, nav) }
            composable("budget") { BudgetScreen(vm, nav) }
            composable("history") { HistoryScreen(vm, nav) }
            composable("inventory") { InventoryScreen(vm, nav) }
            composable("favorites") { FavoritesScreen(vm, nav) }
            composable("scanner") { ScannerScreen(vm, nav) }
        }
    }
}
