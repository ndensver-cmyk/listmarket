package com.mercadolist.ui

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mercadolist.core.*
import com.mercadolist.data.*
import com.mercadolist.work.ReminderScheduler
import com.mercadolist.work.SyncScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import kotlin.math.roundToLong

data class VariantRow(val view: VariantView, val best: PriceView?)
data class Promo(val price: PriceView, val variant: VariantView)
data class StoreTotal(val store: StoreEntity, val total: Long, val covered: Int, val missing: Int, val extra: Long)
data class Assignment(val item: ItemView, val price: PriceView)
data class CompareResult(
    val totals: List<StoreTotal>,
    val distribution: List<Pair<StoreEntity, List<Assignment>>>,
    val distTotal: Long,
    val distExtra: Long,
    val noPrice: List<ItemView>,
    val bestSingle: StoreTotal?,
    val savings: Long?,
    val staleSkipped: Int,
    val itemCount: Int
)

@HiltViewModel
class AppVM @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val db: AppDb,
    private val settingsStore: SettingsStore
) : ViewModel() {

    private val cat = db.catalog()
    private val priceDao = db.price()
    private val listDao = db.lists()
    private val fin = db.finance()
    private val personal = db.personal()

    private fun <T> Flow<T>.state(initial: T): StateFlow<T> = stateIn(viewModelScope, SharingStarted.Eagerly, initial)

    val ready = MutableStateFlow(false)

    init {
        viewModelScope.launch {
            CatalogSeeder(db, ctx).seedIfNeeded()
            ready.value = true
        }
    }

    // ---------- Estado global ----------
    val settings = settingsStore.flow.state(AppSettings())
    val categories = cat.categories().state(emptyList())
    val catalogCount = cat.variantCountFlow().state(0)
    val stores = priceDao.stores().state(emptyList())
    val branches = priceDao.branches().state(emptyList())
    val lists = listDao.lists().state(emptyList())
    val templates = listDao.templates().state(emptyList())
    val summaries = listDao.summaries().map { l -> l.associateBy { it.listId } }.state(emptyMap())
    val activeList = listDao.activeList().state(null)
    val pendingCart = listDao.pendingTotal().state(0.0)
    val inventory = personal.inventory().state(emptyList())
    val purchases = fin.purchases().state(emptyList())
    val favoriteRows: StateFlow<List<VariantRow>> = personal.favorites().map { attach(it) }.state(emptyList())

    val promotions: StateFlow<List<Promo>> = priceDao.promotions().map { prices ->
        val now = System.currentTimeMillis()
        val current = prices.filter { it.isCurrent(now) }
        val vs = cat.variants(current.map { it.variantId }.distinct()).associateBy { it.variantId }
        current.mapNotNull { p -> vs[p.variantId]?.let { Promo(p, it) } }
    }.state(emptyList())

    // ---------- Catálogo ----------
    private suspend fun attach(vs: List<VariantView>): List<VariantRow> {
        if (vs.isEmpty()) return emptyList()
        val now = System.currentTimeMillis()
        val best = priceDao.latestForVariants(vs.map { it.variantId })
            .filter { it.isCurrent(now) }
            .groupBy { it.variantId }
            .mapValues { e -> e.value.minBy { it.price } }
        return vs.map { VariantRow(it, best[it.variantId]) }
    }

    fun search(query: String, categoryId: Long): Flow<List<VariantRow>> {
        val tokens = normalize(query).split(Regex("\\s+")).filter { it.isNotBlank() }
        val pattern = "%" + tokens.joinToString("%") + "%"
        return cat.search(pattern, categoryId, 300).map { attach(it) }
    }

    suspend fun variant(id: Long) = cat.variant(id)
    suspend fun variantsOfProduct(productId: Long) = cat.variantsOfProduct(productId)
    suspend fun barcodes(id: Long) = cat.barcodesOf(id)
    suspend fun substitutes(v: VariantView) = attach(cat.substitutes(v.categoryId, v.subcategory, v.productId, v.productName, v.amount))
    fun prices(id: Long) = priceDao.latestForVariant(id)
    fun history(id: Long) = priceDao.history(id)
    fun isFavorite(id: Long) = personal.isFavorite(id)

    fun toggleFavorite(id: Long, isFav: Boolean) {
        viewModelScope.launch { if (isFav) personal.removeFavorite(id) else personal.addFavorite(FavoriteEntity(id)) }
    }

    fun createCustomProduct(name: String, brand: String, categoryId: Long, presentation: String, amount: Double, unit: String, onDone: (Long) -> Unit) {
        viewModelScope.launch {
            val brandName = brand.ifBlank { "Sin marca" }
            val b = cat.brandByName(brandName) ?: BrandEntity(name = brandName).let { it.copy(id = cat.insertBrand(it)) }
            val pid = cat.insertProduct(ProductEntity(name = name, brandId = b.id, categoryId = categoryId, subcategory = "Personalizados", isCustom = true))
            val vid = cat.insertVariant(
                VariantEntity(
                    productId = pid, sku = "CU-" + System.currentTimeMillis(), label = "", presentation = presentation.ifBlank { "Unidad" },
                    amount = amount, unit = unit, search = normalize("$name $brandName $presentation")
                )
            )
            onDone(vid)
        }
    }

    // ---------- Precios ----------
    fun registerPrice(variantId: Long, storeId: Long, price: Long, original: Long?, city: String, inStock: Boolean) {
        viewModelScope.launch {
            val src = priceDao.sources().first { it.name == "Registrado por el usuario" }
            priceDao.insertPrice(
                PriceEntity(
                    variantId = variantId, storeId = storeId, price = price, originalPrice = original, city = city.ifBlank { "Sin ciudad" },
                    sourceId = src.id, consultedAt = System.currentTimeMillis(), status = PriceStatus.REGISTRADO.name, inStock = inStock
                )
            )
            priceDao.storeById(storeId)?.let { s ->
                if (s.sourceStatus == StoreSource.PENDIENTE.name) priceDao.updateStore(s.copy(sourceStatus = StoreSource.MANUAL.name))
            }
        }
    }

    private suspend fun currentBest(ids: List<Long>): Map<Long, Long> {
        if (ids.isEmpty()) return emptyMap()
        val now = System.currentTimeMillis()
        return priceDao.latestForVariants(ids).filter { it.isCurrent(now) }.groupBy { it.variantId }.mapValues { e -> e.value.minOf { it.price } }
    }

    // ---------- Tiendas ----------
    fun addStore(name: String) { viewModelScope.launch { priceDao.insertStore(StoreEntity(name = name.trim(), isCustom = true)) } }
    fun updateStore(s: StoreEntity) { viewModelScope.launch { priceDao.updateStore(s) } }
    fun addBranch(storeId: Long, city: String, address: String) { viewModelScope.launch { priceDao.insertBranch(StoreBranchEntity(storeId = storeId, city = city, address = address)) } }

    // ---------- Listas ----------
    fun list(id: Long) = listDao.list(id)
    fun items(id: Long) = listDao.items(id)

    fun createList(name: String, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            onDone(listDao.insertList(ShoppingListEntity(name = name.ifBlank { "Mi lista" }, createdAt = now, updatedAt = now)))
        }
    }

    fun copyList(id: Long, asTemplate: Boolean, name: String, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val src = listDao.listOnce(id) ?: return@launch
            val now = System.currentTimeMillis()
            val newId = listDao.insertList(ShoppingListEntity(name = name, createdAt = now, updatedAt = now, isTemplate = asTemplate, budget = src.budget))
            val items = listDao.itemsOnce(id)
            val best = if (asTemplate) emptyMap() else currentBest(items.mapNotNull { it.variantId })
            items.forEach {
                val price = if (it.variantId != null && !asTemplate) best[it.variantId] else it.unitPrice
                listDao.insertItem(it.copy(id = 0, listId = newId, purchased = false, unitPrice = price))
            }
            onDone(newId)
        }
    }

    fun renameList(id: Long, name: String) { viewModelScope.launch { listDao.listOnce(id)?.let { listDao.updateList(it.copy(name = name, updatedAt = System.currentTimeMillis())) } } }
    fun setListBudget(id: Long, budget: Long?) { viewModelScope.launch { listDao.listOnce(id)?.let { listDao.updateList(it.copy(budget = budget)) } } }
    fun deleteList(id: Long) { viewModelScope.launch { listDao.deleteItemsOf(id); listDao.deleteList(id) } }
    fun setActive(id: Long) { viewModelScope.launch { listDao.clearActive(); listDao.listOnce(id)?.let { listDao.updateList(it.copy(isActive = true)) } } }

    private suspend fun touch(listId: Long) { listDao.listOnce(listId)?.let { listDao.updateList(it.copy(updatedAt = System.currentTimeMillis())) } }

    fun addVariant(listId: Long, variantId: Long, qty: Double = 1.0) {
        viewModelScope.launch {
            val v = cat.variant(variantId) ?: return@launch
            val existing = listDao.itemsOnce(listId).firstOrNull { it.variantId == variantId }
            if (existing != null) listDao.updateItem(existing.copy(quantity = existing.quantity + qty))
            else listDao.insertItem(ListItemEntity(listId = listId, variantId = variantId, categoryId = v.categoryId, quantity = qty, unitPrice = currentBest(listOf(variantId))[variantId]))
            touch(listId)
        }
    }

    fun addManual(listId: Long, name: String, qty: Double, price: Long?, categoryId: Long) {
        viewModelScope.launch {
            listDao.insertItem(ListItemEntity(listId = listId, customName = name, categoryId = categoryId, quantity = qty, unitPrice = price))
            touch(listId)
        }
    }

    fun updateItem(id: Long, qty: Double, price: Long?) {
        viewModelScope.launch { listDao.itemById(id)?.let { listDao.updateItem(it.copy(quantity = qty, unitPrice = price)); touch(it.listId) } }
    }

    fun togglePurchased(id: Long, value: Boolean) {
        viewModelScope.launch { listDao.itemById(id)?.let { listDao.updateItem(it.copy(purchased = value)); touch(it.listId) } }
    }

    fun deleteItem(id: Long) { viewModelScope.launch { listDao.itemById(id)?.let { listDao.deleteItem(id); touch(it.listId) } } }

    fun changeVariant(itemId: Long, variantId: Long, qty: Double) {
        viewModelScope.launch {
            val it = listDao.itemById(itemId) ?: return@launch
            listDao.updateItem(it.copy(variantId = variantId, quantity = qty, unitPrice = currentBest(listOf(variantId))[variantId]))
        }
    }

    suspend fun shareText(listId: Long): String {
        val l = listDao.listOnce(listId) ?: return ""
        val items = listDao.itemViewsOnce(listId)
        val sb = StringBuilder("🛒 ${l.name}\n")
        var total = 0.0
        items.forEach {
            val sub = (it.unitPrice ?: 0L) * it.quantity
            total += sub
            val pres = it.presentation?.let { p -> " ($p)" } ?: ""
            sb.append(if (it.purchased) "✅ " else "⬜ ")
                .append("${Fmt.qty(it.quantity)} × ${it.name}$pres")
                .append(if (it.unitPrice == null) " — sin precio" else " — ${Fmt.cop(sub)}")
                .append('\n')
        }
        sb.append("Total estimado: ${Fmt.cop(total)}\nCreada con MercadoList")
        return sb.toString()
    }

    suspend fun exportPdf(listId: Long): File = withContext(Dispatchers.IO) {
        val l = listDao.listOnce(listId)!!
        val items = listDao.itemViewsOnce(listId)
        val doc = PdfDocument()
        val title = Paint().apply { textSize = 20f; isFakeBoldText = true }
        val body = Paint().apply { textSize = 12f }
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
        var y = 60f
        page.canvas.drawText(l.name, 40f, y, title); y += 24f
        page.canvas.drawText("MercadoList · ${Fmt.date(System.currentTimeMillis())}", 40f, y, body); y += 28f
        var total = 0.0
        for (item in items) {
            if (y > 790f) {
                doc.finishPage(page); pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create()); y = 60f
            }
            val sub = (item.unitPrice ?: 0L) * item.quantity
            total += sub
            val mark = if (item.purchased) "[x]" else "[ ]"
            val name = (item.name + (item.presentation?.let { " · $it" } ?: "")).take(46)
            page.canvas.drawText("$mark ${Fmt.qty(item.quantity)} × $name", 40f, y, body)
            page.canvas.drawText(if (item.unitPrice == null) "sin precio" else Fmt.cop(sub), 450f, y, body)
            y += 18f
        }
        y += 14f
        page.canvas.drawText("Total estimado: ${Fmt.cop(total)}", 40f, y, title)
        doc.finishPage(page)
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, l.name.replace(Regex("[^A-Za-z0-9]+"), "_").take(30).ifBlank { "lista" } + ".pdf")
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        f
    }

    // ---------- Comparador ----------
    suspend fun compare(listId: Long, includeStale: Boolean, delivery: Boolean): CompareResult {
        val items = listDao.itemViewsOnce(listId).filter { !it.purchased }
        val withV = items.filter { it.variantId != null }
        val manual = items.filter { it.variantId == null }
        val manualPriced = manual.filter { it.unitPrice != null }
        val manualConst = manualPriced.sumOf { ((it.unitPrice ?: 0L) * it.quantity).roundToLong() }
        val storeList = priceDao.storesOnce()
        val now = System.currentTimeMillis()
        val prices = if (withV.isEmpty()) emptyList() else priceDao.latestForVariants(withV.mapNotNull { it.variantId }.distinct())
        val latest = prices.groupBy { it.variantId to it.storeId }.mapValues { e -> e.value.maxBy { it.consultedAt } }
        fun ok(p: PriceView) = p.inStock && (includeStale || now - p.consultedAt <= STALE_MS)
        val stale = latest.values.count { !includeStale && now - it.consultedAt > STALE_MS }

        val totals = storeList.map { s ->
            var total = manualConst
            var covered = manualPriced.size
            withV.forEach { it ->
                val p = latest[it.variantId!! to s.id]
                if (p != null && ok(p)) { total += (p.price * it.quantity).roundToLong(); covered++ }
            }
            StoreTotal(s, total, covered, items.size - covered, if (delivery) s.deliveryCost else s.transportCost)
        }.filter { it.covered > manualPriced.size }.sortedWith(compareBy({ it.missing }, { it.total + it.extra }))

        val assign = LinkedHashMap<StoreEntity, MutableList<Assignment>>()
        val noPrice = ArrayList<ItemView>()
        withV.forEach { it ->
            val best = storeList.mapNotNull { s -> latest[it.variantId!! to s.id]?.takeIf { p -> ok(p) }?.let { p -> s to p } }.minByOrNull { pair -> pair.second.price }
            if (best == null) { noPrice.add(it) } else { assign.getOrPut(best.first) { mutableListOf() }.add(Assignment(it, best.second)) }
        }
        noPrice += manual.filter { it.unitPrice == null }
        val distTotal = assign.values.sumOf { l -> l.sumOf { (it.price.price * it.item.quantity).roundToLong() } } + manualConst
        val distExtra = assign.keys.sumOf { if (delivery) it.deliveryCost else it.transportCost }
        val bestSingle = totals.firstOrNull { it.missing == 0 }
        val savings = bestSingle?.let { (it.total + it.extra) - (distTotal + distExtra) }
        return CompareResult(totals, assign.entries.map { it.key to it.value.toList() }, distTotal, distExtra, noPrice, bestSingle, savings, stale, items.size)
    }

    // ---------- Compras y presupuesto ----------
    fun finishPurchase(listId: Long, storeName: String, onDone: () -> Unit) {
        viewModelScope.launch {
            val l = listDao.listOnce(listId) ?: return@launch
            val all = listDao.itemViewsOnce(listId)
            val use = all.filter { it.purchased }.ifEmpty { all }
            val now = System.currentTimeMillis()
            val total = use.sumOf { ((it.unitPrice ?: 0L) * it.quantity).roundToLong() }
            val pid = fin.insertPurchase(PurchaseEntity(name = l.name, date = now, total = total, storeName = storeName))
            fin.insertPurchaseItems(use.map {
                PurchaseItemEntity(purchaseId = pid, variantId = it.variantId, name = it.name, categoryId = it.categoryId, quantity = it.quantity, unitPrice = it.unitPrice ?: 0L)
            })
            listDao.updateList(l.copy(completedAt = now, isActive = false, updatedAt = now))
            onDone()
        }
    }

    fun repeatPurchase(purchaseId: Long, name: String, onDone: (Long) -> Unit) {
        viewModelScope.launch {
            val items = fin.purchaseItems(purchaseId)
            val now = System.currentTimeMillis()
            val newId = listDao.insertList(ShoppingListEntity(name = "$name (repetido)", createdAt = now, updatedAt = now))
            val best = currentBest(items.mapNotNull { it.variantId })
            items.forEach {
                listDao.insertItem(
                    ListItemEntity(
                        listId = newId, variantId = it.variantId, customName = if (it.variantId == null) it.name else null,
                        categoryId = it.categoryId, quantity = it.quantity,
                        unitPrice = if (it.variantId != null) best[it.variantId] else it.unitPrice.takeIf { p -> p > 0 }
                    )
                )
            }
            onDone(newId)
        }
    }

    suspend fun purchaseItems(id: Long) = fin.purchaseItems(id)
    fun deletePurchase(id: Long) { viewModelScope.launch { fin.deletePurchaseItems(id); fin.deletePurchase(id) } }

    fun budgets(period: String) = fin.budgets(period)
    fun spendByCategory(r: Pair<Long, Long>) = fin.spendByCategory(r.first, r.second)
    fun spent(r: Pair<Long, Long>) = fin.spent(r.first, r.second)
    fun setBudget(period: String, categoryId: Long, amount: Long?) {
        viewModelScope.launch {
            if (amount == null || amount <= 0) fin.deleteBudget(period, categoryId)
            else fin.upsertBudget(BudgetEntity(period = period, categoryId = categoryId, amount = amount))
        }
    }

    // ---------- Inventario doméstico ----------
    fun saveInventory(i: InventoryEntity) { viewModelScope.launch { personal.upsertInventory(i) } }
    fun deleteInventory(i: InventoryEntity) { viewModelScope.launch { personal.deleteInventory(i) } }

    /** Crea una lista con los productos del inventario que se acabaron (cantidad 0). */
    fun listFromInventory(onDone: (Long) -> Unit) {
        viewModelScope.launch {
            val missing = inventory.value.filter { it.quantity <= 0 }
            val now = System.currentTimeMillis()
            val id = listDao.insertList(ShoppingListEntity(name = "Lo que falta en casa", createdAt = now, updatedAt = now))
            missing.forEach { inv ->
                val v = inv.productId?.let { cat.variantsOfProduct(it).firstOrNull() }
                if (v != null) listDao.insertItem(ListItemEntity(listId = id, variantId = v.variantId, categoryId = v.categoryId, unitPrice = currentBest(listOf(v.variantId))[v.variantId]))
                else listDao.insertItem(ListItemEntity(listId = id, customName = inv.name))
            }
            onDone(id)
        }
    }

    // ---------- Escáner e importación ----------
    fun lookupEan(ean: String, onResult: (Long?) -> Unit) { viewModelScope.launch { onResult(cat.variantIdByEan(ean)) } }
    fun linkEan(ean: String, variantId: Long) { viewModelScope.launch { cat.insertBarcode(BarcodeEntity(ean, variantId)) } }

    /**
     * CSV (separador ; o ,):
     *  - sku;tienda;ciudad;precio[;precio_antes]  -> registra precio
     *  - sku;codigoEAN                            -> vincula código de barras
     *  - sku;urlFoto                              -> asigna fotografía
     */
    suspend fun importCsv(uri: Uri): String = withContext(Dispatchers.IO) {
        val lines = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readLines() } ?: return@withContext "No se pudo abrir el archivo"
        var prices = 0; var images = 0; var codes = 0; var skipped = 0
        val src = priceDao.sources().first { it.name == "Importado (CSV)" }
        val touched = HashSet<Long>()
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#") || line.lowercase().startsWith("sku")) continue
            val c = line.split(if (line.contains(';')) ';' else ',').map { it.trim() }
            val vid = cat.variantIdBySku(c[0])
            if (vid == null) { skipped++; continue }
            if (c.size == 2) {
                if (c[1].matches(Regex("\\d{8,14}"))) { cat.insertBarcode(BarcodeEntity(c[1], vid)); codes++ }
                else if (c[1].startsWith("http")) { cat.setVariantImage(vid, c[1]); images++ } else skipped++
            } else if (c.size >= 4) {
                val price = c[3].toMoney()
                if (price == null || price <= 0) { skipped++; continue }
                val store = priceDao.storeByName(c[1]) ?: StoreEntity(name = c[1], isCustom = true).let { it.copy(id = priceDao.insertStore(it)) }
                priceDao.insertPrice(
                    PriceEntity(
                        variantId = vid, storeId = store.id, price = price, originalPrice = c.getOrNull(4)?.toMoney(), city = c[2].ifBlank { "Sin ciudad" },
                        sourceId = src.id, consultedAt = System.currentTimeMillis(), status = PriceStatus.REGISTRADO.name
                    )
                )
                touched += store.id
                prices++
            } else skipped++
        }
        touched.forEach { id -> priceDao.storeById(id)?.let { priceDao.updateStore(it.copy(sourceStatus = StoreSource.IMPORTADO.name)) } }
        "Importado: $prices precios, $codes códigos de barras, $images fotos. Omitidas: $skipped."
    }

    // ---------- Ajustes ----------
    fun setDark(v: Int) { viewModelScope.launch { settingsStore.setDark(v) } }
    fun setCity(v: String) { viewModelScope.launch { settingsStore.setCity(v.trim()) } }
    fun setPeriod(v: String) { viewModelScope.launch { settingsStore.setPeriod(v) } }
    fun setReminder(on: Boolean, day: Int, hour: Int) {
        viewModelScope.launch {
            settingsStore.setReminder(on, day, hour)
            if (on) ReminderScheduler.schedule(ctx, day, hour) else ReminderScheduler.cancel(ctx)
        }
    }
    fun setSync(on: Boolean) { viewModelScope.launch { settingsStore.setSync(on); SyncScheduler.apply(ctx, on) } }
}
