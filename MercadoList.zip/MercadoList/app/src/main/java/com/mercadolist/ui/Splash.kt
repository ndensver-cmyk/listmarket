package com.mercadolist.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Animación de arranque: el carrito rebota, caen productos dentro y aparece el nombre. */
@Composable
fun SplashOverlay(onFinished: () -> Unit) {
    val cart = remember { Animatable(0f) }
    val tilt = remember { Animatable(-14f) }
    val drops = remember { List(3) { Animatable(0f) } }
    val title = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { cart.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = 260f)) }
            launch { tilt.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 200f)) }
        }
        coroutineScope {
            drops.forEachIndexed { i, a ->
                launch { delay(i * 160L); a.animateTo(1f, tween(480, easing = FastOutSlowInEasing)) }
            }
        }
        title.animateTo(1f, tween(450))
        delay(650)
        fade.animateTo(0f, tween(350))
        onFinished()
    }

    Box(
        Modifier.fillMaxSize().graphicsLayer { alpha = fade.value }.background(Yellow),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(170.dp), contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Filled.ShoppingCart, null, tint = Ink,
                    modifier = Modifier.size(120.dp).graphicsLayer { scaleX = cart.value; scaleY = cart.value; rotationZ = tilt.value }
                )
                listOf("🍎", "🥛", "🍞").forEachIndexed { i, e ->
                    val p = drops[i].value
                    if (p > 0f && p < 1f) {
                        Text(
                            e, fontSize = 26.sp,
                            modifier = Modifier
                                .offset(x = ((i - 1) * 30).dp, y = (-120 * (1 - p) - 4).dp)
                                .graphicsLayer { alpha = if (p > 0.85f) (1f - p) / 0.15f else 1f }
                        )
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "MercadoList", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Ink,
                modifier = Modifier.graphicsLayer { alpha = title.value; translationY = (1 - title.value) * 40f }
            )
            Text(
                "Tu mercado organizado", fontSize = 15.sp, color = Ink.copy(alpha = 0.75f),
                modifier = Modifier.graphicsLayer { alpha = title.value }
            )
        }
    }
}
