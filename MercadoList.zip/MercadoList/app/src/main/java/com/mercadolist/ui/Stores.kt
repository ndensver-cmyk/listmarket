@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.mercadolist.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.mercadolist.core.*
import com.mercadolist.data.StoreEntity
import kotlinx.coroutines.launch

@Composable
fun StoresScreen(vm: AppVM, nav: NavController) {
    val stores by vm.stores.collectAsState()
    val branches by vm.branches.collectAsState()
    var addStore by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<StoreEntity?>(null) }
    var branchFor by remember { mutableStateOf<StoreEntity?>(null) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { snack.showSnackbar(vm.importCsv(uri), duration = SnackbarDuration.Long) }
    }

    Screen(
        title = "Supermercados", onBack = { nav.popBackStack() }, snackbar = snack,
        fab = { ExtendedFloatingActionButton(onClick = { addStore = true }, containerColor = Yellow, contentColor = Ink) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Supermercado") } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                InfoCard {
                    Text("Origen de los precios", fontWeight = FontWeight.Bold)
                    Text(
                        "Incluir una cadena no significa que sus precios estén disponibles. Cada tienda muestra el estado de su fuente: verificado, actualizado manualmente, importado o pendiente. No se inventan cotizaciones.",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Icon(Icons.Filled.UploadFile, null); Spacer(Modifier.width(6.dp)); Text("Importar CSV") }
                    Text("Formato: sku;tienda;ciudad;precio[;precio_antes]  ·  sku;código EAN  ·  sku;url de la foto", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(stores, key = { it.id }) { s ->
                val cities = branches.filter { it.storeId == s.id }
                InfoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(s.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                        if (s.isCustom) Text("Personalizado", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    SourceChip(s.sourceStatus)
                    Spacer(Modifier.height(6.dp))
                    Text("Transporte: ${Fmt.cop(s.transportCost)}  ·  Domicilio: ${Fmt.cop(s.deliveryCost)}", fontSize = 13.sp)
                    Text(if (cities.isEmpty()) "Sin sucursales registradas" else "Sucursales: " + cities.joinToString { it.city + if (it.address.isNotBlank()) " (${it.address})" else "" }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { edit = s }) { Text("Costos y estado") }
                        TextButton(onClick = { branchFor = s }) { Text("Agregar sucursal") }
                    }
                }
            }
        }
    }

    if (addStore) TextInputDialog("Nuevo supermercado", "Nombre", onSave = { vm.addStore(it) }, onDismiss = { addStore = false })
    edit?.let { s -> StoreEditDialog(s, onSave = { vm.updateStore(it) }, onDismiss = { edit = null }) }
    branchFor?.let { s -> BranchDialog(s.name, onSave = { c, a -> vm.addBranch(s.id, c, a) }, onDismiss = { branchFor = null }) }
}

@Composable
private fun StoreEditDialog(s: StoreEntity, onSave: (StoreEntity) -> Unit, onDismiss: () -> Unit) {
    var transport by remember { mutableStateOf(s.transportCost.toString()) }
    var delivery by remember { mutableStateOf(s.deliveryCost.toString()) }
    var status by remember { mutableStateOf(s.sourceStatus) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(s.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                NumberField(transport, { transport = it }, "Costo de transporte (COP)", Modifier.fillMaxWidth())
                NumberField(delivery, { delivery = it }, "Costo de domicilio (COP)", Modifier.fillMaxWidth())
                Text("Estado de la fuente de precios", fontWeight = FontWeight.SemiBold)
                StoreSource.entries.forEach { st ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = status == st.name, onClick = { status = st.name }); Text(st.label)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(s.copy(transportCost = transport.toMoney() ?: 0L, deliveryCost = delivery.toMoney() ?: 0L, sourceStatus = status)); onDismiss() }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun BranchDialog(store: String, onSave: (String, String) -> Unit, onDismiss: () -> Unit) {
    var city by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Sucursal de $store") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(city, { city = it }, label = { Text("Ciudad") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(address, { address = it }, label = { Text("Dirección (opcional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(enabled = city.isNotBlank(), onClick = { onSave(city.trim(), address.trim()); onDismiss() }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
