package com.mercadolist.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.mercadolist.R
import java.util.Calendar
import java.util.concurrent.TimeUnit

const val CHANNEL_ID = "recordatorios"

fun createChannels(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Recordatorios de mercado", NotificationManager.IMPORTANCE_DEFAULT))
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        createChannels(ctx)
        val allowed = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (allowed) {
            val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_agenda)
                .setContentTitle("Hoy toca el mercado")
                .setContentText("Revisa tu lista en MercadoList antes de salir.")
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(ctx).notify(1001, n)
        }
        // Reprograma la siguiente semana
        ReminderScheduler.schedule(ctx, inputData.getInt("day", 1), inputData.getInt("hour", 9))
        return Result.success()
    }
}

object ReminderScheduler {
    private const val NAME = "mercado_reminder"

    fun schedule(ctx: Context, day: Int, hour: Int) {
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(nextDelayMs(day, hour), TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("day" to day, "hour" to hour))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(NAME, ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
    }

    private fun nextDelayMs(day: Int, hour: Int): Long {
        val now = Calendar.getInstance()
        val t = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, day); set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (t.timeInMillis <= now.timeInMillis) t.add(Calendar.WEEK_OF_YEAR, 1)
        return t.timeInMillis - now.timeInMillis
    }
}

/**
 * Sincronización opcional. La app es local-first: todo funciona sin conexión.
 * Aquí se conectará Supabase (usuarios, respaldo y catálogos compartidos) cuando se configure.
 */
class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = Result.success()
}

object SyncScheduler {
    private const val NAME = "mercadolist_sync"

    fun apply(ctx: Context, enabled: Boolean) {
        val wm = WorkManager.getInstance(ctx)
        if (!enabled) { wm.cancelUniqueWork(NAME); return }
        val req = PeriodicWorkRequestBuilder<SyncWorker>(12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}
