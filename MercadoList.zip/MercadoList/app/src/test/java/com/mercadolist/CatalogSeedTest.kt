package com.mercadolist

import com.mercadolist.data.CatalogGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class CatalogSeedTest {
    private val refs by lazy { CatalogGenerator.generate(File("src/main/assets/catalog_seed.txt").readLines()) }

    @Test fun hasAtLeast5000References() {
        assertTrue("Solo hay ${refs.size} referencias", refs.size >= 5000)
    }

    @Test fun noDuplicatedReferences() {
        val keys = refs.map { listOf(it.category, it.subcategory, it.product, it.brand, it.variant, it.presentation, it.amount, it.unit) }
        assertEquals(keys.size, keys.toSet().size)
    }

    @Test fun coversAll14Categories() {
        assertEquals(CatalogGenerator.categories.toSet(), refs.map { it.category }.toSet())
    }
}
