package com.mercadolist

import com.mercadolist.data.CatalogGenerator
import com.mercadolist.data.PriceEstimator
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class PriceModelTest {
    private val refs = CatalogGenerator.generate(File("src/main/assets/catalog_seed.txt").readLines())
    private val model = PriceEstimator.parse(File("src/main/assets/price_model.txt").readLines())

    @Test fun everyProductHasAPriceModel() {
        val missing = refs.map { "${it.category}|${it.product}" }.toSet() - model.keys
        assertTrue("Sin modelo de precio: $missing", missing.isEmpty())
    }

    @Test fun estimatesArePositiveAndStoreBrandsStayInTheirStore() {
        for (r in refs) {
            val m = model.getValue("${r.category}|${r.product}")
            for (s in PriceEstimator.storeFactors.keys) {
                val p = PriceEstimator.estimate(m, r.amount, r.unit, r.variant, r.presentation, r.brand, s, "X")
                if (r.brand.startsWith("Marca propia ") && r.brand != "Marca propia $s") assertTrue(p == null)
                else assertTrue("${r.product} ${r.brand} $s", p != null && p > 0)
            }
        }
    }
}
