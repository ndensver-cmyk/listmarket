# Reglas para release con minificación (desactivada por defecto).
